"""
中国竞彩足球攻略 VPS版（PostgreSQL）
- 三栏Tab：竞彩解析 / 泊松欧赔 / 传统足彩
- 适配VPS PostgreSQL（matches/odds_euro/odds_asia）
- 纯数据展示，不做推荐
"""

import json
import math
import os
from datetime import date, datetime, timedelta
from pathlib import Path

# 繁体转简体（可选）
try:
    from opencc import OpenCC
    _t2s = OpenCC('t2s')
    def t2s(name):
        return _t2s.convert(name) if name else name
except ImportError:
    def t2s(name):
        return name

# 联赛白名单
from league_tier import should_include_match, LEAGUE_TIER

import psycopg2
import psycopg2.extras

# =================== 配置 ===================
PG_DSN = os.getenv("PG_DSN", "postgresql://ruipan:Ruipan2026!@127.0.0.1:5432/ruipan")
OUTPUT_PATH = Path(os.getenv("JCZQ_OUTPUT", "/opt/ruipan/static/jczq-recommend.html"))
PERIODS_PATH = Path(__file__).parent / "zc_periods.json"

# 日期周期：中午12:00 ~ 次日11:59
def get_noon_day():
    now = datetime.now()
    d = now.date()
    if now.hour < 12:
        d = d - timedelta(days=1)
    return d

# 17档系数
COEFF_TABLE = {
    0: 0.55, 0.25: 0.75, 0.5: 1, 0.75: 1.5, 1: 2, 1.25: 2.5, 1.5: 3,
    1.75: 3.5, 2: 4, 2.25: 4.5, 2.5: 5, 2.75: 5.5, 3: 6, 3.25: 6.5,
    3.5: 7, 3.75: 7.5, 4: 8
}

BOOKMAKER_NAMES = {
    "macau": "澳门", "crown": "皇冠", "bet365": "Bet365",
    "yibosheng": "易胜博", "vcbet": "伟德", "mansion88": "Mansion88",
    "pinnacle": "平博", "sbobet": "Sbobet", "wewbet": "Wewbet",
    "williamhill": "威廉希尔",
}
BK_ORDER = ["crown", "macau", "williamhill", "bet365", "pinnacle", "yibosheng", "wewbet", "vcbet"]

# =================== DB辅助 ===================

def get_conn():
    return psycopg2.connect(PG_DSN)

def fetch_odds_for_match(conn, match_id_pk):
    """从PG获取一场比赛的欧赔+亚盘，组装成旧版odds_data格式"""
    odds_by_phase = {}

    # 欧赔
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("""
            SELECT bookmaker, home_win, draw, away_win, odds_type
            FROM odds_euro
            WHERE match_id = %s
              AND bookmaker = ANY(%s)
        """, (str(match_id_pk), BK_ORDER))
        euro_rows = cur.fetchall()

    euro_map = {}
    for r in euro_rows:
        key = (r['bookmaker'], r['odds_type'])
        euro_map[key] = {
            'odds_h': float(r['home_win']) if r['home_win'] is not None else None,
            'odds_d': float(r['draw']) if r['draw'] is not None else None,
            'odds_a': float(r['away_win']) if r['away_win'] is not None else None,
        }

    # 亚盘
    with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
        cur.execute("""
            SELECT bookmaker, handicap, home_odds, away_odds, odds_type
            FROM odds_asia
            WHERE match_id = %s
              AND bookmaker = ANY(%s)
        """, (str(match_id_pk), BK_ORDER))
        asia_rows = cur.fetchall()

    asia_map = {}
    for r in asia_rows:
        key = (r['bookmaker'], r['odds_type'])
        asia_map[key] = {
            'asian_handicap': float(r['handicap']) if r['handicap'] is not None else None,
            'asian_upper_odds': float(r['home_odds']) if r['home_odds'] is not None else None,
            'asian_lower_odds': float(r['away_odds']) if r['away_odds'] is not None else None,
        }

    # 合并
    all_keys = set(euro_map.keys()) | set(asia_map.keys())
    for key in all_keys:
        merged = {}
        if key in euro_map:
            merged.update(euro_map[key])
        if key in asia_map:
            merged.update(asia_map[key])
        merged['bookmaker'] = key[0]
        merged['phase_type'] = key[1]
        odds_by_phase[key] = merged

    return odds_by_phase


# =================== 足彩期号 ===================

def load_periods():
    if PERIODS_PATH.exists():
        with open(PERIODS_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        "current": {"period": "26098", "matches": []},
        "previous": {"period": "26097", "matches": []}
    }


# =================== 名称映射 ===================

ZC_TO_CROWN = {
    '赫根': '赫根', '卡尔马': '卡尔马', '腓特烈斯塔': '腓特烈斯塔',
    '桑纳菲尤尔': '桑纳菲', '斯达': '斯达', '维京': '维京',
    '拉赫蒂': '拉赫蒂', '雅罗': '查路', '赫尔辛基火花': 'HIFK',
    '库奥皮奥': '古比斯', '瓦斯科达伽马': '华斯高', '弗鲁米嫩塞': '富明尼斯',
}

def zc_name_to_crown(zc_name):
    if not zc_name:
        return zc_name
    return ZC_TO_CROWN.get(zc_name, zc_name)


# =================== 数据查询 ===================

def query_matches():
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            # noon-based: 从昨天中午到3天后
            now = datetime.now()
            start = (now - timedelta(days=1)).strftime('%Y-%m-%d 12:00')
            end = (now + timedelta(days=3)).strftime('%Y-%m-%d 12:00')
            cur.execute("""
                SELECT m.id, m.match_id, m.match_time, m.status,
                       m.home_score, m.away_score,
                       m.home_team, m.away_team, m.league
                FROM matches m
                WHERE m.match_time >= %s
                  AND m.match_time <= %s
                  AND EXISTS (
                      SELECT 1 FROM odds_euro e
                      WHERE e.match_id = m.match_id AND e.odds_type = 'initial'
                  )
                ORDER BY m.match_time
            """, (start, end))
            rows = cur.fetchall()

        matches = []
        for row in rows:
            m = dict(row)
            league = m.get('league') or ''
            tier, _ = should_include_match(league)
            if tier is None or tier == 0:
                continue
            m['id'] = m['match_id']  # use match_id string for odds lookup
            m['odds_data'] = fetch_odds_for_match(conn, m['match_id'])
            matches.append(m)
        return matches
    finally:
        conn.close()


def try_match_zc_match(home_name, away_name, match_date):
    """将足彩比赛匹配到PG中的比赛"""
    conn = get_conn()
    try:
        crown_home = zc_name_to_crown(home_name)
        crown_away = zc_name_to_crown(away_name)
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute("""
                SELECT id, match_id, match_time, status, home_score, away_score,
                       home_team, away_team, league
                FROM matches
                WHERE match_time >= %s AND match_time < %s
                ORDER BY match_time
            """, (match_date + " 00:00",
                  (datetime.strptime(match_date, "%Y-%m-%d") + timedelta(days=2)).strftime('%Y-%m-%d') + " 00:00"))
            rows = cur.fetchall()

        best_match = None
        best_score = 0
        for row in rows:
            db_home = t2s(row['home_team'])
            db_away = t2s(row['away_team'])
            score = 0
            if crown_home == db_home: score += 12
            elif crown_home in db_home or db_home in crown_home: score += 8
            if crown_away == db_away: score += 12
            elif crown_away in db_away or db_away in crown_away: score += 8
            if score < 14:
                orig = 0
                if home_name == db_home: orig += 8
                elif home_name in db_home or db_home in home_name: orig += 5
                if away_name == db_away: orig += 8
                elif away_name in db_away or db_away in away_name: orig += 5
                score = max(score, orig)
            if score > best_score and score >= 8:
                best_score = score
                best_match = dict(row)
                best_match['id'] = best_match['match_id']

        if best_match:
            best_match['odds_data'] = fetch_odds_for_match(conn, best_match['match_id'])
        return best_match
    finally:
        conn.close()


# =================== 工具函数 ===================

def get_coeff(hdp):
    abs_h = abs(hdp)
    for k in sorted(COEFF_TABLE.keys()):
        if abs_h <= k:
            return COEFF_TABLE[k]
    return COEFF_TABLE[max(COEFF_TABLE.keys())]

def hdp_group(h):
    a = abs(h)
    if a == 0: return '平手'
    if a <= 0.25: return '平半'
    if a <= 0.5: return '半球'
    if a <= 0.75: return '半一'
    if a <= 1.0: return '一球'
    if a <= 1.5: return '球半'
    return '两球+'

def water_bin(w):
    if w < 0.85: return '超低水'
    if w < 0.95: return '低水'
    if w < 1.05: return '中水'
    return '高水'

def divg_bin(d):
    if d < -0.10: return '负分歧'
    if d < 0.05: return '微正分歧'
    if d < 0.20: return '小正分歧'
    if d < 0.50: return '中正分歧'
    return '强正分歧'

def fmt_handicap(v):
    if v is None or v == '': return '—'
    v = float(v)
    if v == 0: return '平手'
    av = abs(v)
    if av == 0.25: return '平半'
    if av == 0.5: return '半球'
    if av == 0.75: return '半一'
    if av == 1.0: return '一球'
    if av == 1.25: return '一球/球半'
    if av == 1.5: return '球半'
    if av == 1.75: return '球半/两'
    if av == 2.0: return '两球'
    return f'{av}球'

def fmt_diff(d):
    if d is None: return '—'
    sign = '+' if d >= 0 else ''
    color = '#00e676' if d > 0.05 else '#ff5252' if d < -0.05 else '#ffb74d'
    return f'<span style="color:{color}">{sign}{d:.2f}</span>'

def fmt_hdp_with_dir(hdp, odds_h=None, odds_a=None):
    base = fmt_handicap(hdp)
    if base == '—': return base
    if base == '平手':
        if odds_h is not None and odds_a is not None and odds_h > 0 and odds_a > 0:
            if odds_h <= odds_a:
                return '<span style="font-size:0.45rem;color:var(--text-muted)">主让</span>平手'
            else:
                return '<span style="font-size:0.45rem;color:var(--text-muted)">客让</span>平手'
        return '<span style="font-size:0.45rem;color:var(--text-muted)">主让</span>平手'
    direction = '主让' if hdp > 0 else '客让'
    return f'<span style="font-size:0.45rem;color:var(--text-muted)">{direction}</span>{base}'

# =================== 查找表 ===================

def load_pred_model():
    pred_path = Path(__file__).parent / "pred_model_v3_upper.json"
    if pred_path.exists():
        with open(pred_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data.get('L1', {}), data.get('L2', {}), data.get('L3', {})
    return {}, {}, {}

def lookup_win_rate(L1, L2, L3, bookmaker, hdp, water, divg):
    hdp_g = hdp_group(hdp)
    water_b = water_bin(water)
    divg_b = divg_bin(divg)
    key1 = f"{bookmaker}|{hdp_g}|{water_b}|{divg_b}"
    if key1 in L1 and L1[key1]['n'] >= 3:
        return L1[key1]
    key2 = f"{hdp_g}|{water_b}|{divg_b}"
    if key2 in L2 and L2[key2]['n'] >= 3:
        return L2[key2]
    key3 = f"{hdp_g}|{water_b}"
    if key3 in L3 and L3[key3]['n'] >= 3:
        return L3[key3]
    return None

# =================== 泊松分布 ===================

def poisson_pmf(k, lam):
    if lam <= 0: return 1.0 if k == 0 else 0.0
    return (lam ** k) * math.exp(-lam) / math.factorial(k)

def implied_prob(odds_h, odds_d, odds_a):
    raw_h, raw_d, raw_a = 1/odds_h, 1/odds_d, 1/odds_a
    total = raw_h + raw_d + raw_a
    if total == 0: return 0.333, 0.333, 0.334
    return raw_h/total, raw_d/total, raw_a/total

def calc_score_matrix_simple(lambda_h, lambda_a, max_g=6):
    ph, pd, pa = 0.0, 0.0, 0.0
    for h in range(max_g + 1):
        for a in range(max_g + 1):
            p = poisson_pmf(h, lambda_h) * poisson_pmf(a, lambda_a)
            if h > a: ph += p
            elif h == a: pd += p
            else: pa += p
    return ph, pd, pa

def estimate_goals(odds_h, odds_d, odds_a, hdp=0):
    p_h, p_d, p_a = implied_prob(odds_h, odds_d, odds_a)
    best_lh, best_la = 1.3, 1.3
    best_error = float('inf')
    for lh in [x * 0.1 for x in range(5, 35)]:
        for la in [x * 0.1 for x in range(5, 35)]:
            cp_h, cp_d, cp_a = calc_score_matrix_simple(lh, la)
            error = (cp_h - p_h)**2 + (cp_d - p_d)**2 + (cp_a - p_a)**2
            if error < best_error:
                best_error = error
                best_lh, best_la = lh, la
    for lh in [best_lh + x * 0.02 for x in range(-10, 11)]:
        if lh < 0.3 or lh > 3.5: continue
        for la in [best_la + x * 0.02 for x in range(-10, 11)]:
            if la < 0.3 or la > 3.5: continue
            cp_h, cp_d, cp_a = calc_score_matrix_simple(lh, la)
            error = (cp_h - p_h)**2 + (cp_d - p_d)**2 + (cp_a - p_a)**2
            if error < best_error:
                best_error = error
                best_lh, best_la = lh, la
    return best_lh, best_la

def calc_score_matrix(lambda_h, lambda_a, max_g=7):
    matrix = {}
    for h in range(max_g + 1):
        for a in range(max_g + 1):
            matrix[(h, a)] = poisson_pmf(h, lambda_h) * poisson_pmf(a, lambda_a)
    return matrix

def calc_total_goals_dist(score_matrix):
    dist = {}
    for (h, a), p in score_matrix.items():
        t = h + a
        dist[t] = dist.get(t, 0) + p
    return dist

def calc_1x2_from_matrix(score_matrix):
    ph, pd, pa = 0, 0, 0
    for (h, a), p in score_matrix.items():
        if h > a: ph += p
        elif h == a: pd += p
        else: pa += p
    return ph, pd, pa

# =================== 分析 ===================

def calc_phase_data(odds, bk, L1, L2, L3):
    hdp = odds.get('asian_handicap')
    if hdp is None: return None
    upper = odds.get('asian_upper_odds')
    if upper is None: return None
    euro_h = odds.get('odds_h')
    euro_a = odds.get('odds_a')
    euro = euro_h if hdp >= 0 else euro_a
    if not euro: return None
    coeff = get_coeff(hdp)
    divg = (euro - 1.0) * coeff - upper
    wr_data = lookup_win_rate(L1, L2, L3, bk, hdp, upper, divg)
    return {'hdp': hdp, 'upper': upper, 'divg': divg, 'wr': wr_data, 'euro_h': euro_h, 'euro_a': euro_a}


def analyze_match(match, L1, L2, L3):
    result = {'match': match, 'bookmakers': [], 'poisson': None, 'euro_odds': None}
    bk_phases = {}
    for (bk, phase), o in match['odds_data'].items():
        if bk not in bk_phases:
            bk_phases[bk] = {}
        bk_phases[bk][phase] = o
    for bk in BK_ORDER:
        if bk not in bk_phases:
            continue
        phases = bk_phases[bk]
        ini = phases.get('initial', {})
        is_finished = match.get('status') == 'finished'
        latest = phases.get('closing') if is_finished else phases.get('live')
        if not latest:
            latest = phases.get('initial', {})
        if not ini.get('odds_h'):
            continue
        bk_data = {
            'name': BOOKMAKER_NAMES.get(bk, bk),
            'initial': calc_phase_data(ini, bk, L1, L2, L3),
            'latest': calc_phase_data(latest, bk, L1, L2, L3),
        }
        result['bookmakers'].append(bk_data)

    # 泊松基础参数：皇冠/澳彩/威廉希尔三家初盘欧赔平均值
    ref = None
    POISSON_BKS = ['crown', 'macau', 'williamhill']
    h_list, d_list, a_list = [], [], []
    hdp_ref = None
    for bk in POISSON_BKS:
        o = match['odds_data'].get((bk, 'initial'))
        if o and o.get('odds_h') and o.get('odds_d') and o.get('odds_a'):
            h_list.append(o['odds_h'])
            d_list.append(o['odds_d'])
            a_list.append(o['odds_a'])
            if hdp_ref is None and o.get('asian_handicap') is not None:
                hdp_ref = o['asian_handicap']
    if h_list:
        ref = {
            'odds_h': sum(h_list) / len(h_list),
            'odds_d': sum(d_list) / len(d_list),
            'odds_a': sum(a_list) / len(a_list),
            'asian_handicap': hdp_ref if hdp_ref is not None else 0,
        }
        ref['_source_count'] = len(h_list)
    if ref:
        hdp = ref.get('asian_handicap') or 0
        lam_h, lam_a = estimate_goals(ref['odds_h'], ref['odds_d'], ref['odds_a'], hdp)
        score_matrix = calc_score_matrix(lam_h, lam_a)
        total_dist = calc_total_goals_dist(score_matrix)
        top_scores = sorted(score_matrix.items(), key=lambda x: x[1], reverse=True)[:10]
        p1x2 = calc_1x2_from_matrix(score_matrix)
        imp_h, imp_d, imp_a = implied_prob(ref['odds_h'], ref['odds_d'], ref['odds_a'])
        FIXED_HOME = [(1,0),(2,0),(2,1),(3,0),(3,1),(3,2),(4,0),(4,1),(4,2),(5,0),(5,1),(5,2)]
        FIXED_DRAW = [(0,0),(1,1),(2,2),(3,3)]
        FIXED_AWAY  = [(0,1),(0,2),(0,3),(1,2),(1,3),(2,3),(0,4),(1,4),(2,4),(0,5),(1,5),(2,5)]
        home_scores = [(s, score_matrix.get(s, 0)) for s in FIXED_HOME]
        draw_scores = [(s, score_matrix.get(s, 0)) for s in FIXED_DRAW]
        away_scores = [(s, score_matrix.get(s, 0)) for s in FIXED_AWAY]
        listed_sum = sum(v for _, v in home_scores) + sum(v for _, v in draw_scores) + sum(v for _, v in away_scores)
        other_total = max(0, 1.0 - listed_sum)
        home_total = sum(v for _, v in home_scores)
        draw_total = sum(v for _, v in draw_scores)
        away_total = sum(v for _, v in away_scores)
        cat_sum = home_total + draw_total + away_total
        if cat_sum > 0:
            home_other = other_total * (home_total / cat_sum)
            draw_other = other_total * (draw_total / cat_sum)
            away_other = other_total * (away_total / cat_sum)
        else:
            home_other = draw_other = away_other = other_total / 3
        home_scores.append(('other', home_other))
        draw_scores.append(('other', draw_other))
        away_scores.append(('other', away_other))
        result['poisson'] = {
            'lambda_h': lam_h, 'lambda_a': lam_a, 'p1x2': p1x2,
            'total_dist': total_dist, 'top_scores': top_scores,
            'home_scores': home_scores, 'draw_scores': draw_scores, 'away_scores': away_scores,
            'hdp': hdp,
        }
        result['euro_odds'] = {
            'odds_h': ref['odds_h'], 'odds_d': ref['odds_d'], 'odds_a': ref['odds_a'],
            'imp_h': imp_h, 'imp_d': imp_d, 'imp_a': imp_a,
        }
    return result

def group_by_status(analyzed_matches):
    finished, live, not_started = [], [], []
    for am in analyzed_matches:
        st = am['match'].get('status', '')
        if st == 'finished': finished.append(am)
        elif st == 'live': live.append(am)
        else: not_started.append(am)
    return finished, live, not_started

def wr_color(wr):
    if wr >= 50: return '#00e676'
    if wr >= 35: return '#69f0ae'
    if wr >= 25: return '#f9a825'
    if wr >= 15: return '#ffb74d'
    return '#ff5252'

# =================== HTML渲染（原样保留） ===================

def render_analysis_section(am):
    bks = am['bookmakers']
    if not bks:
        return ''
    html = '<div class="section"><div class="section-title">📊 盘口解析</div>'
    html += '<table class="analysis-table"><thead><tr>'
    html += '<th class="bk-name">公司</th><th>初盘</th><th>即时</th><th>分歧</th><th>胜率</th>'
    html += '</tr></thead><tbody>'
    for bk in bks:
        ini = bk['initial']
        lat = bk['latest']
        if not ini and not lat:
            continue
        html += '<tr>'
        html += f'<td class="bk-name">{bk["name"]}</td>'
        # 初盘
        if ini:
            hdp_str = fmt_hdp_with_dir(ini['hdp'], ini.get('euro_h'), ini.get('euro_a'))
            html += f'<td class="phase-init">{hdp_str}<br><span style="font-size:0.5rem;color:var(--text-muted)">{ini["upper"]:.2f}</span></td>'
        else:
            html += '<td class="phase-init">—</td>'
        # 即时
        if lat:
            hdp_str = fmt_hdp_with_dir(lat['hdp'], lat.get('euro_h'), lat.get('euro_a'))
            diff = lat['divg'] - ini['divg'] if ini else 0
            html += f'<td class="phase-latest">{hdp_str}<br><span style="font-size:0.5rem;color:var(--text-muted)">{lat["upper"]:.2f} {fmt_diff(diff)}</span></td>'
        else:
            html += '<td class="phase-latest">—</td>'
        # 分歧
        if lat:
            html += f'<td>{fmt_diff(lat["divg"])}</td>'
        else:
            html += '<td>—</td>'
        # 胜率
        wr = lat.get('wr') if lat else None
        if wr:
            wr_val = wr.get('win_rate', wr.get('wr', 0))
            color = wr_color(wr_val)
            html += f'<td style="color:{color};font-weight:600">{wr_val:.0f}%</td>'
        else:
            html += '<td style="color:var(--text-muted)">—</td>'
        html += '</tr>'
    html += '</tbody></table></div>'
    return html


def render_poisson_section(am):
    p = am.get('poisson')
    euro = am.get('euro_odds')
    if not p or not euro:
        return ''
    lh, la = p['lambda_h'], p['lambda_a']
    p1x2 = p['p1x2']
    html = '<div class="section"><div class="section-title">🎯 泊松模型</div>'
    # 三个概率盒子
    html += f'''<div style="display:flex;gap:4px;margin-bottom:8px;">
  <div style="flex:1;background:rgba(0,230,118,0.08);border:1px solid rgba(0,230,118,0.2);border-radius:6px;padding:6px;text-align:center;">
    <div style="font-size:0.55rem;color:var(--text-secondary)">主胜</div>
    <div style="font-size:1rem;font-weight:700;color:var(--accent-green)">{p1x2[0]*100:.1f}%</div>
  </div>
  <div style="flex:1;background:rgba(255,215,0,0.08);border:1px solid rgba(255,215,0,0.2);border-radius:6px;padding:6px;text-align:center;">
    <div style="font-size:0.55rem;color:var(--text-secondary)">平局</div>
    <div style="font-size:1rem;font-weight:700;color:var(--accent-gold)">{p1x2[1]*100:.1f}%</div>
  </div>
  <div style="flex:1;background:rgba(68,138,255,0.08);border:1px solid rgba(68,138,255,0.2);border-radius:6px;padding:6px;text-align:center;">
    <div style="font-size:0.55rem;color:var(--text-secondary)">客胜</div>
    <div style="font-size:1rem;font-weight:700;color:var(--accent-blue)">{p1x2[2]*100:.1f}%</div>
  </div>
</div>'''
    html += f'<div style="font-size:0.55rem;color:var(--text-muted);text-align:center;margin-bottom:6px;">λ主={lh:.2f} λ客={la:.2f} | 欧赔 {euro["odds_h"]:.2f}/{euro["odds_d"]:.2f}/{euro["odds_a"]:.2f}</div>'
    # 比分概率
    html += '<div style="font-size:0.6rem;color:var(--accent-cyan);margin-bottom:4px;">最可能比分</div>'
    html += '<div class="score-grid">'
    for (h, a), prob in p['top_scores'][:5]:
        html += f'''<div class="score-cell">
  <div class="score-val">{h}:{a}</div>
  <div class="score-prob">{prob*100:.1f}%</div>
</div>'''
    html += '</div></div>'
    return html


# =================== 足彩14场渲染 ===================

def render_match_card_prev(cur, analyzed_matches):
    """上期结果"""
    matches = cur.get('matches', [])
    period = cur.get('period', '---')
    html = ''
    matched_count = 0
    for m in matches:
        seq = m.get('seq', '')
        league = m.get('league', '')
        home = m.get('home', '')
        away = m.get('away', '')
        match_date = m.get('date', '')
        score = m.get('score', '')
        result_badge = ''
        if score:
            result_badge = '<span style="background:rgba(0,230,118,0.1);color:var(--accent-green);font-size:0.55rem;padding:1px 6px;border-radius:3px;">已完场</span>'
        else:
            result_badge = '<span style="background:rgba(255,255,255,0.05);color:var(--text-muted);font-size:0.55rem;padding:1px 6px;border-radius:3px;">待赛</span>'
        db_match = try_match_zc_match(home, away, match_date)
        if db_match:
            matched_count += 1
            full_match = {
                'id': db_match['id'],
                'match_time': db_match['match_time'],
                'status': db_match['status'],
                'home_score': db_match['home_score'],
                'away_score': db_match['away_score'],
                'home_team': db_match['home_team'],
                'away_team': db_match['away_team'],
                'league': db_match.get('league') or league,
                'odds_data': db_match['odds_data'],
            }
            L1, L2, L3 = load_pred_model()
            am = analyze_match(full_match, L1, L2, L3)
            html += '<div class="match-card">'
            html += f'''<div class="match-head">
  <span class="match-league">第{period}期 {seq}场 · {league}</span>
  <span class="match-time">{match_date[5:] if match_date else ''} {result_badge}</span>
</div>'''
            db_home_display = t2s(db_match['home_team'])
            db_away_display = t2s(db_match['away_team'])
            home_line = f'{home}' + (f'<span style="font-size:0.5rem;color:var(--text-muted);margin-left:4px">({db_home_display})</span>' if db_home_display != home else '')
            away_line = f'{away}' + (f'<span style="font-size:0.5rem;color:var(--text-muted);margin-left:4px">({db_away_display})</span>' if db_away_display != away else '')
            if score:
                teams_html = f'<span class="team-h">{home_line}</span><span class="score-inline">{score}</span><span class="team-a">{away_line}</span>'
            else:
                hs, aws = db_match.get('home_score'), db_match.get('away_score')
                if hs is not None and aws is not None:
                    teams_html = f'<span class="team-h">{home_line}</span><span class="score-inline">{hs}:{aws}</span><span class="team-a">{away_line}</span>'
                else:
                    teams_html = f'<span class="team-h">{home_line}</span><span class="vs-mark">VS</span><span class="team-a">{away_line}</span>'
            html += f'<div class="match-teams">{teams_html}</div>'
            if am['bookmakers']:
                html += render_analysis_section(am)
            if am.get('poisson'):
                html += render_poisson_section(am)
            html += '</div>'
        else:
            html += f'''<div class="match-card">
<div class="match-head">
  <span class="match-league">第{period}期 {seq}场 · {league}</span>
  <span class="match-time">{match_date[5:] if match_date else ''} {result_badge}</span>
</div>
<div class="match-teams">
  <span class="team-h">{home}</span>'''
            if score:
                html += f'<span class="score-inline">{score}</span>'
            else:
                html += '<span class="vs-mark">VS</span>'
            html += f'''<span class="team-a">{away}</span>
</div>
<div class="section" style="color:var(--text-muted);font-size:0.65rem;text-align:center;padding:10px;">
  暂未获取到赔率数据
</div>
</div>'''
    if matched_count > 0:
        html += f'<div style="text-align:center;margin-top:8px;font-size:0.5rem;color:var(--text-muted);">第{period}期</div>'
    return html


def render_cur_period(cur, analyzed_matches):
    matches = cur.get('matches', [])
    period = cur.get('period', '---')
    html = ''
    matched_count = 0
    L1, L2, L3 = load_pred_model()
    for m in matches:
        seq = m.get('seq', '')
        league = m.get('league', '')
        home = m.get('home', '')
        away = m.get('away', '')
        match_date = m.get('date', '')
        db_match = try_match_zc_match(home, away, match_date)
        if db_match:
            matched_count += 1
            full_match = {
                'id': db_match['id'],
                'match_time': db_match['match_time'],
                'status': db_match['status'],
                'home_score': db_match['home_score'],
                'away_score': db_match['away_score'],
                'home_team': db_match['home_team'],
                'away_team': db_match['away_team'],
                'league': db_match.get('league') or league,
                'odds_data': db_match['odds_data'],
            }
            am = analyze_match(full_match, L1, L2, L3)
            html += '<div class="match-card">'
            crown_home = zc_name_to_crown(home)
            crown_away = zc_name_to_crown(away)
            html += f'''<div class="match-head">
  <span class="match-league">第{period}期 {seq}场 · {league}</span>
  <span class="match-time">{match_date[5:]}</span>
</div>'''
            db_home_display = t2s(db_match['home_team'])
            db_away_display = t2s(db_match['away_team'])
            home_line = f'{home}' + (f'<span style="font-size:0.5rem;color:var(--text-muted);margin-left:4px">({db_home_display})</span>' if db_home_display != home else '')
            away_line = f'{away}' + (f'<span style="font-size:0.5rem;color:var(--text-muted);margin-left:4px">({db_away_display})</span>' if db_away_display != away else '')
            status = db_match.get('status', '')
            if status == 'finished':
                hs, aws = db_match.get('home_score'), db_match.get('away_score')
                score_str = f'{hs}:{aws}' if hs is not None and aws is not None else ''
                teams_html = f'<span class="team-h">{home_line}</span><span class="score-inline">{score_str}</span><span class="team-a">{away_line}</span><span class="match-status-badge badge-finished">终场</span>'
            elif status == 'live':
                hs, aws = db_match.get('home_score'), db_match.get('away_score')
                score_str = f'{hs}:{aws}' if hs is not None and aws is not None else ''
                teams_html = f'<span class="team-h">{home_line}</span><span class="score-inline live">{score_str}</span><span class="team-a">{away_line}</span><span class="match-status-badge badge-live">LIVE</span>'
            else:
                teams_html = f'<span class="team-h">{home_line}</span><span class="vs-mark">VS</span><span class="team-a">{away_line}</span>'
            html += f'<div class="match-teams">{teams_html}</div>'
            if am['bookmakers']:
                html += render_analysis_section(am)
            if am.get('poisson'):
                html += render_poisson_section(am)
            html += '</div>'
        else:
            html += f'''<div class="match-card">
<div class="match-head">
  <span class="match-league">第{period}期 {seq}场 · {league}</span>
  <span class="match-time">{match_date[5:]}</span>
</div>
<div class="match-teams">
  <span class="team-h">{home}</span><span class="vs-mark">VS</span><span class="team-a">{away}</span>
</div>
<div class="section" style="color:var(--text-muted);font-size:0.65rem;text-align:center;padding:10px;">
  暂未获取到赔率数据
</div>
</div>'''
    if matched_count > 0:
        html += f'<div style="text-align:center;margin-top:8px;font-size:0.5rem;color:var(--text-muted);">第{period}期</div>'
    else:
        html += '<div style="text-align:center;margin-top:8px;font-size:0.5rem;color:var(--text-muted);">暂无数据</div>'
    return html


# =================== HTML生成 ===================

def generate_html(analyzed_matches, periods_data):
    today = get_noon_day()
    today_str = today.strftime("%Y年%m月%d日")
    finished, live, not_started = group_by_status(analyzed_matches)

    cur_period = periods_data.get('current', {})
    prev_period = periods_data.get('previous', {})
    cur_period_no = cur_period.get('period', '---')

    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&display=swap" rel="stylesheet">
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>RuiPan·锐盘 | 竞彩攻略 - {today_str}</title>
<style>
:root {{
  --bg-primary:#0a0e27;--bg-card:#151a38;--bg-card-alt:#1a1f3a;
  --border:rgba(255,255,255,0.08);--border-gold:rgba(255,215,0,0.15);
  --text-primary:#e0e6ff;--text-secondary:#8892b0;--text-muted:#5a6380;
  --accent-gold:#ffd700;--accent-green:#00e676;--accent-red:#ff5252;
  --accent-blue:#448aff;--accent-cyan:#4dd0e1;--accent-orange:#ff6f00;
}}
* {{ margin:0;padding:0;box-sizing:border-box; }}
body {{ font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif; background:var(--bg-primary); color:var(--text-primary); font-size:13px; }}

.rp-header {{ background:linear-gradient(135deg,#0d1230 0%,#1a1040 40%,#0d1230 100%);border-bottom:1px solid rgba(255,215,0,0.12);padding:14px 16px 10px;position:relative;overflow:hidden; }}
.rp-header::before {{ content:'';position:absolute;inset:0;background:repeating-linear-gradient(90deg,transparent,transparent 60px,rgba(255,255,255,0.015) 60px,rgba(255,255,255,0.015) 61px),repeating-linear-gradient(0deg,transparent,transparent 60px,rgba(255,255,255,0.015) 60px,rgba(255,255,255,0.015) 61px); }}
.rp-header::after {{ content:'';position:absolute;top:0;left:-100%;width:60%;height:100%;background:linear-gradient(90deg,transparent,rgba(255,215,0,0.04),transparent);animation:rp-sweep 4s ease-in-out infinite; }}
@keyframes rp-sweep {{ 0%{{left:-60%}} 100%{{left:120%}} }}
.rp-top {{ display:flex;align-items:center;justify-content:space-between;position:relative;z-index:1; }}
.rp-brand {{ display:flex;align-items:center;gap:8px; }}
.rp-logo {{ font-size:1.2rem;font-weight:800;letter-spacing:1px;background:linear-gradient(135deg,#ffd700 0%,#ff9100 50%,#ffd700 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;animation:rp-shimmer 3s ease-in-out infinite; }}
@keyframes rp-shimmer {{ 0%,100%{{filter:brightness(1)}} 50%{{filter:brightness(1.3)}} }}
.rp-sub {{ font-family:'Orbitron',sans-serif;font-size:0.55rem;color:var(--text-secondary);letter-spacing:2px;margin-top:1px; }}
.rp-nav-link {{ font-size:0.65rem;color:var(--accent-cyan);text-decoration:none;padding:4px 10px;background:rgba(77,208,225,0.08);border:1px solid rgba(77,208,225,0.2);border-radius:6px;transition:all 0.2s;white-space:nowrap; }}
.rp-nav-link:hover {{ background:rgba(77,208,225,0.15); }}
.rp-edge {{ height:1px;background:linear-gradient(90deg,transparent,rgba(255,215,0,0.3),rgba(0,230,118,0.2),transparent);margin-top:8px;position:relative;z-index:1; }}
.rp-date {{ text-align:center;font-size:0.65rem;color:var(--text-secondary);padding:6px 0 0;position:relative;z-index:1;letter-spacing:1px; }}

.container {{ max-width:480px;margin:0 auto;padding:0 12px 12px; }}

.stats-bar {{ display:flex;gap:8px;justify-content:center;margin:14px 0; }}
.stat-item {{ background:var(--bg-card);border:1px solid var(--border);border-radius:8px;padding:8px 14px;text-align:center;flex:1;position:relative;overflow:hidden; }}
.stat-item::before {{ content:'';position:absolute;top:0;left:0;right:0;height:2px; }}
.stat-item.si-f::before {{ background:linear-gradient(90deg,transparent,var(--text-muted),transparent); }}
.stat-item.si-l::before {{ background:linear-gradient(90deg,transparent,var(--accent-green),transparent); }}
.stat-item.si-n::before {{ background:linear-gradient(90deg,transparent,var(--accent-blue),transparent); }}
.stat-val {{ font-size:1.3rem;font-weight:800; }}
.stat-val.v-f {{ color:var(--text-secondary); }}
.stat-val.v-l {{ color:var(--accent-green); }}
.stat-val.v-n {{ color:var(--accent-blue); }}
.stat-label {{ font-size:0.6rem;color:var(--text-secondary);margin-top:2px; }}

.tab-nav {{ display:flex;gap:0;margin-bottom:14px;border-radius:8px;overflow:hidden;border:1px solid var(--border); }}
.tab-btn {{ flex:1;padding:10px 4px;text-align:center;background:var(--bg-card);color:var(--text-secondary);font-size:0.75rem;font-weight:600;border:none;cursor:pointer;transition:all 0.2s; }}
.tab-btn.active {{ background:var(--accent-gold);color:#0a0e27; }}
.tab-content {{ display:none; }}
.tab-content.active {{ display:block; }}

.sub-tab-nav {{ display:flex;gap:0;margin-bottom:10px;border-radius:6px;overflow:hidden;border:1px solid var(--border-gold); }}
.sub-tab-btn {{ flex:1;padding:8px 4px;text-align:center;background:var(--bg-card);color:var(--text-secondary);font-size:0.7rem;font-weight:600;border:none;cursor:pointer; }}
.sub-tab-btn.active {{ background:rgba(255,215,0,0.15);color:var(--accent-gold); }}
.sub-tab-content {{ display:none; }}
.sub-tab-content.active {{ display:block; }}

.period-info {{ background:var(--bg-card);border:1px solid var(--border-gold);border-radius:8px;padding:8px 12px;margin-bottom:10px; }}
.period-title {{ font-size:0.85rem;font-weight:700;color:var(--accent-gold);text-align:center; }}
.period-meta {{ font-size:0.6rem;color:var(--text-secondary);text-align:center;margin-top:4px; }}

.group-header {{ font-size:0.7rem;color:var(--accent-cyan);font-weight:600;padding:8px 12px 4px;margin-top:6px;display:flex;align-items:center;gap:6px; }}
.group-header .dot {{ width:6px;height:6px;border-radius:50%;display:inline-block; }}
.group-header .dot.finished {{ background:var(--text-muted); }}
.group-header .dot.live {{ background:var(--accent-green);animation:pulse 1.5s infinite; }}
.group-header .dot.not_started {{ background:var(--accent-blue); }}
@keyframes pulse {{ 0%,100%{{opacity:1}} 50%{{opacity:0.4}} }}

.match-card {{ background:var(--bg-card);border-radius:10px;margin-bottom:10px;border:1px solid var(--border);overflow:hidden; }}
.match-head {{ padding:6px 12px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center; }}
.match-league {{ font-size:0.65rem;color:var(--accent-cyan);font-weight:500; }}
.match-time {{ font-size:0.65rem;color:var(--text-secondary); }}
.match-teams {{ padding:6px 12px;font-size:0.85rem;font-weight:600;display:flex;align-items:center;justify-content:center;gap:6px; }}
.team-h, .team-a {{ color:var(--text-primary); }}
.score-inline {{ font-size:0.9rem;font-weight:700;color:var(--accent-gold);font-family:monospace; }}
.score-inline.live {{ color:var(--accent-green); }}
.vs-mark {{ font-size:0.75rem;color:var(--text-muted);font-weight:400; }}
.match-status-badge {{ font-size:0.5rem;padding:1px 5px;border-radius:3px;margin-left:4px; }}
.badge-finished {{ background:rgba(255,255,255,0.08);color:var(--text-muted); }}
.badge-live {{ background:rgba(0,230,118,0.15);color:var(--accent-green); }}

.section {{ padding:0 12px 10px; }}
.section-title {{ font-size:0.72rem;color:var(--accent-gold);margin:8px 0 6px;font-weight:600; }}

.analysis-table {{ width:100%;border-collapse:collapse;font-size:0.65rem; }}
.analysis-table th {{ background:rgba(255,255,255,0.03);color:var(--text-secondary);font-weight:500;padding:4px 2px;text-align:center;font-size:0.55rem;border-bottom:1px solid var(--border); }}
.analysis-table td {{ padding:4px 2px;text-align:center;border-bottom:1px solid rgba(255,255,255,0.04); }}
.analysis-table .bk-name {{ text-align:left;font-weight:500;color:var(--text-primary);white-space:nowrap;font-size:0.6rem; }}
.phase-init {{ color:var(--text-secondary); }}
.phase-latest {{ font-weight:600; }}

.score-grid {{ display:grid;grid-template-columns:repeat(5,1fr);gap:3px;margin-bottom:6px; }}
.score-cell {{ background:rgba(68,138,255,0.08);border:1px solid rgba(68,138,255,0.2);border-radius:6px;padding:6px 2px;text-align:center; }}
.score-val {{ font-size:0.8rem;font-weight:700; }}
.score-prob {{ font-size:0.55rem;color:var(--accent-cyan);margin-top:2px; }}
</style>
</head>
<body>
<div class="rp-header">
  <div class="rp-top">
    <div class="rp-brand">
      <div>
        <div class="rp-logo">RuiPan·锐盘</div>
        <div class="rp-sub">FOOTBALL DATA INTELLIGENCE</div>
      </div>
    </div>
    <a href="/" class="rp-nav-link">⚡ 即时比分</a>
  </div>
  <div class="rp-edge"></div>
  <div class="rp-date">竞彩攻略 · {today_str}</div>
</div>

<div class="container">
  <div class="stats-bar">
    <div class="stat-item si-f"><div class="stat-val v-f">{len(finished)}</div><div class="stat-label">已完场</div></div>
    <div class="stat-item si-l"><div class="stat-val v-l">{len(live)}</div><div class="stat-label">进行中</div></div>
    <div class="stat-item si-n"><div class="stat-val v-n">{len(not_started)}</div><div class="stat-label">未开赛</div></div>
  </div>

  <div class="tab-nav">
    <div class="tab-btn active" onclick="switchTab(0)">竞彩解析</div>
    <div class="tab-btn" onclick="switchTab(1)">泊松欧赔</div>
    <div class="tab-btn" onclick="switchTab(2)">传统足彩</div>
  </div>

  <!-- Tab1: 竞彩解析 -->
  <div class="tab-content active" id="tab0">
'''

    for group, items, label, dot_cls in [
        (finished, finished, "已完场", "finished"),
        (live, live, "进行中", "live"),
        (not_started, not_started, "未开赛", "not_started"),
    ]:
        if not items:
            continue
        html += f'<div class="group-header"><span class="dot {dot_cls}"></span>{label} ({len(items)})</div>'
        for am in items:
            m = am['match']
            html += '<div class="match-card">'
            html += f'''<div class="match-head">
  <span class="match-league">{m.get('league','')}</span>
  <span class="match-time">{m['match_time'].strftime('%m-%d %H:%M') if hasattr(m['match_time'],'strftime') else str(m['match_time'])[5:16]}</span>
</div>'''
            status = m.get('status', '')
            home_disp = t2s(m.get('home_team', ''))
            away_disp = t2s(m.get('away_team', ''))
            if status == 'finished':
                hs, aws = m.get('home_score'), m.get('away_score')
                score_str = f'{hs}:{aws}' if hs is not None and aws is not None else ''
                teams_html = f'<span class="team-h">{home_disp}</span><span class="score-inline">{score_str}</span><span class="team-a">{away_disp}</span><span class="match-status-badge badge-finished">终场</span>'
            elif status == 'live':
                hs, aws = m.get('home_score'), m.get('away_score')
                score_str = f'{hs}:{aws}' if hs is not None and aws is not None else ''
                teams_html = f'<span class="team-h">{home_disp}</span><span class="score-inline live">{score_str}</span><span class="team-a">{away_disp}</span><span class="match-status-badge badge-live">LIVE</span>'
            else:
                teams_html = f'<span class="team-h">{home_disp}</span><span class="vs-mark">VS</span><span class="team-a">{away_disp}</span>'
            html += f'<div class="match-teams">{teams_html}</div>'
            if am['bookmakers']:
                html += render_analysis_section(am)
            html += '</div>'

    html += '''
  </div>

  <!-- Tab2: 泊松欧赔 -->
  <div class="tab-content" id="tab1">
'''
    for group, items, label, dot_cls in [
        (finished, finished, "已完场", "finished"),
        (live, live, "进行中", "live"),
        (not_started, not_started, "未开赛", "not_started"),
    ]:
        if not items:
            continue
        html += f'<div class="group-header"><span class="dot {dot_cls}"></span>{label} ({len(items)})</div>'
        for am in items:
            if not am.get('poisson'):
                continue
            m = am['match']
            html += '<div class="match-card">'
            html += f'''<div class="match-head">
  <span class="match-league">{m.get('league','')}</span>
  <span class="match-time">{m['match_time'].strftime('%m-%d %H:%M') if hasattr(m['match_time'],'strftime') else str(m['match_time'])[5:16]}</span>
</div>'''
            home_disp = t2s(m.get('home_team', ''))
            away_disp = t2s(m.get('away_team', ''))
            teams_html = f'<span class="team-h">{home_disp}</span><span class="vs-mark">VS</span><span class="team-a">{away_disp}</span>'
            html += f'<div class="match-teams">{teams_html}</div>'
            html += render_poisson_section(am)
            html += '</div>'

    html += f'''
  </div>

  <!-- Tab3: 传统足彩 -->
  <div class="tab-content" id="tab2">
    <div class="period-info">
      <div class="period-title">传统足彩14场</div>
      <div class="period-meta">当前第{cur_period_no}期 · 上期第{prev_period.get('period','---')}期</div>
    </div>
    <div class="sub-tab-nav">
      <div class="sub-tab-btn active" onclick="switchSubTab(0)">当期攻略</div>
      <div class="sub-tab-btn" onclick="switchSubTab(1)">上期结果</div>
    </div>
    <div class="sub-tab-content active" id="subtab0">
      {render_cur_period(cur_period, analyzed_matches)}
    </div>
    <div class="sub-tab-content" id="subtab1">
      {render_match_card_prev(prev_period, analyzed_matches)}
    </div>
  </div>
</div>

<script>
function switchTab(i) {{
  document.querySelectorAll('.tab-btn').forEach((b,j)=>b.classList.toggle('active',j===i));
  document.querySelectorAll('.tab-content').forEach((c,j)=>c.classList.toggle('active',j===i));
}}
function switchSubTab(i) {{
  document.querySelectorAll('.sub-tab-btn').forEach((b,j)=>b.classList.toggle('active',j===i));
  document.querySelectorAll('.sub-tab-content').forEach((c,j)=>c.classList.toggle('active',j===i));
}}
</script>
</body>
</html>'''
    return html


# =================== 主函数 ===================

def main():
    print("📊 加载预测模型...")
    L1, L2, L3 = load_pred_model()
    print(f"   L1={len(L1)}桶, L2={len(L2)}桶, L3={len(L3)}桶")

    print("🔍 查询比赛数据...")
    matches = query_matches()
    print(f"   找到 {len(matches)} 场有效比赛")

    print("🧮 分析比赛...")
    analyzed = []
    for m in matches:
        am = analyze_match(m, L1, L2, L3)
        analyzed.append(am)

    finished, live, ns = group_by_status(analyzed)
    print(f"   已完场:{len(finished)} 进行中:{len(live)} 未开赛:{len(ns)}")

    print("📋 加载足彩14场期号数据...")
    periods_data = load_periods()
    print(f"   当期: 第{periods_data['current']['period']}期")
    print(f"   上期: 第{periods_data['previous']['period']}期")

    print("📝 生成HTML...")
    html = generate_html(analyzed, periods_data)

    OUTPUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT_PATH.write_text(html, encoding='utf-8')
    size_kb = OUTPUT_PATH.stat().st_size / 1024
    print(f"✅ 已生成: {OUTPUT_PATH} ({size_kb:.1f} KB)")


if __name__ == '__main__':
    main()
