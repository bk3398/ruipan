#!/bin/bash
# 黄金监控 + 数据采集 cron wrapper
# 交易时段：周一06:00 ~ 周六05:00（北京时间），夏/冬令时自动处理
# 数据采集每2分钟一次，监控每5分钟一次
# 日志：/var/log/ruipan_gold.log

set -e
export RUIPAN_GOLD_DIR=/opt/ruipan/gold
export SERVERCHAN_SENDKEY="${SERVERCHAN_SENDKEY:-__SENDKEY_PLACEHOLDER__}"
export PATH=/usr/local/bin:/usr/bin:/bin:$PATH
LOG=/var/log/ruipan_gold.log
cd "$RUIPAN_GOLD_DIR"

TZ_BJ=$(TZ='Asia/Shanghai' date '+%u %H %M')
DOW=$(echo "$TZ_BJ" | awk '{print $1}')  # 1=Mon..7=Sun
HOUR=$(echo "$TZ_BJ" | awk '{print $2}')
MIN=$(echo "$TZ_BJ" | awk '{print $3}')
NOW=$(TZ='Asia/Shanghai' date '+%Y-%m-%d %H:%M:%S')

# 周六05:00后 ~ 周一06:00前 休市
if [ "$DOW" = "7" ] || { [ "$DOW" = "6" ] && [ "$HOUR" -ge 5 ]; } || { [ "$DOW" = "1" ] && [ "$HOUR" -lt 6 ]; }; then
    echo "[$NOW] 休市，跳过" >> "$LOG"
    exit 0
fi

case "$1" in
    collect)
        /usr/bin/python3 gold_data_collector_vps.py >> "$LOG" 2>&1
        ;;
    monitor)
        /usr/bin/python3 xauusd_monitor_vps.py auto >> "$LOG" 2>&1
        ;;
    *)
        echo "usage: $0 {collect|monitor}"
        exit 1
        ;;
esac
