#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""黄金超短线交易监控 VPS 独立版（V3策略实盘版，去除Coze SDK依赖）

部署路径：/opt/ruipan/gold/
推送通道：Server酱（FTQQ/SCT），通过环境变量 SERVERCHAN_SENDKEY 配置
          未配置时仅控制台输出（不推送）
图表输出：/opt/ruipan/gold/charts/xauusd_monitor.png
          nginx 映射为 https://<域名>/static/gold/xauusd_monitor.png

参数（命令行）：
  argv[1] result_mode: auto / display_only / notify / no_reply（默认 auto）
  argv[2] stop_loss_pts（默认 500）
  argv[3] floating_loss_warn（默认 200）
"""

import json
import math
import os
import sqlite3
import sys
import time
import traceback
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from enum import Enum
from typing import Any, Dict, List, Optional, Tuple

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
import pandas as pd
import requests

# yfinance: 运行时检测并安装
try:
    import yfinance as yf
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "yfinance", "-q"])
    import yfinance as yf


# ===== 路径常量（VPS） =====
_BASE_DIR = os.environ.get("RUIPAN_GOLD_DIR", "/opt/ruipan/gold")
DB_PATH = os.path.join(_BASE_DIR, "gold_data.db")
POSITION_STATE_PATH = os.path.join(_BASE_DIR, "monitor_position_state.json")
OUTPUT_DIR = _BASE_DIR
CHART_DIR = os.path.join(_BASE_DIR, "charts")
# 图表对外URL前缀（nginx 映射）；未配置时不在推送消息里附链接
CHART_URL_PREFIX = os.environ.get(
    "RUIPAN_GOLD_CHART_URL",
    "https://perhaps-equation-thumbzilla-state.trycloudflare.com/static/gold",
)

# ===== Server酱推送配置 =====
SERVERCHAN_SENDKEY = os.environ.get("SERVERCHAN_SENDKEY", "").strip()


def serverchan_push(title: str, desp: str) -> bool:
    """通过 Server酱 Turbo 版推送到微信。
    SendKey 为空时不推送，仅打印。返回是否推送成功。
    """
    if not SERVERCHAN_SENDKEY:
        print(f"[推送-未配置SENDKEY] title={title}")
        print(desp)
        return False
    url = f"https://sctapi.ftqq.com/{SERVERCHAN_SENDKEY}.send"
    try:
        # Server酱 desp 支持 Markdown
        r = requests.post(url, data={"title": title[:32], "desp": desp}, timeout=10)
        ok = r.status_code == 200 and r.json().get("code") == 0
        print(f"[推送-Server酱] {'成功' if ok else '失败'}: {r.status_code} {r.text[:200]}")
        return ok
    except Exception as e:
        print(f"[推送-Server酱] 异常: {e}")
        return False

# ===== 数据源常量 =====
XAUS_SPOT_URL = "https://xaus.com/api/v1/spot"
XAUS_INTRADAY_URL = "https://xaus.com/api/v1/intraday"
YFINANCE_TICKER = "GC=F"
_YF_TICKERS = [YFINANCE_TICKER, "XAUUSD=X"]

# ===== 策略参数 =====
SAR_AF = 0.02
SAR_MAX_AF = 0.2
KDJ_K_PERIOD = 9
KDJ_D_PERIOD = 3
CONFIRM_WINDOW = 3          # 进仓确认窗口（1m K线数）
SAR_SUSTAIN_BARS = 3        # SAR反转持续确认K线数
COOLDOWN_BARS = 3           # 冷却期（1m K线数）= 3分钟
STOP_LOSS_POINTS = 500      # 止损阈值（点数）
FLOATING_LOSS_WARN = 200    # 浮亏预警阈值（点数）
DB_BARS_LOAD = 500          # 从数据库加载的K线数量

# ===== 休市判断常量 =====
BJ_TZ = timezone(timedelta(hours=8))

_HOLIDAYS: Dict[int, Dict[str, str]] = {
    2026: {
        "2026-01-01": "元旦",
        "2026-01-19": "马丁·路德·金纪念日",
        "2026-02-16": "总统日",
        "2026-04-03": "耶稣受难日",
        "2026-04-06": "复活节星期一",
        "2026-05-25": "阵亡将士纪念日",
        "2026-06-19": "六月节",
        "2026-07-03": "独立日（补休）",
        "2026-09-07": "劳动节",
        "2026-11-26": "感恩节",
        "2026-12-25": "圣诞节",
        "2026-12-26": "节礼日",
    },
}


# ===== 数据结构 =====
class PositionSide(Enum):
    LONG = "long"
    SHORT = "short"


class PositionState(Enum):
    FULL = "full"
    HALF = "half"


@dataclass
class OHLCV:
    timestamp: int
    open: float
    high: float
    low: float
    close: float


# ===== SAR 计算（与V3回测完全一致） =====

def calc_sar(bars: List[OHLCV], af: float = SAR_AF, max_af: float = SAR_MAX_AF) -> List[float]:
    """计算 Parabolic SAR"""
    n = len(bars)
    if n < 2:
        return [0.0] * n

    sar_list = [0.0] * n
    is_long = bars[1].high > bars[0].high
    if is_long:
        sar = min(bars[0].low, bars[1].low)
        ep = max(bars[0].high, bars[1].high)
    else:
        sar = max(bars[0].high, bars[1].high)
        ep = min(bars[0].low, bars[1].low)

    sar_list[0] = sar
    sar_list[1] = sar
    cur_af = af

    for i in range(2, n):
        prev_sar = sar
        sar = prev_sar + cur_af * (ep - prev_sar)

        if is_long:
            sar = min(sar, bars[i - 1].low, bars[i - 2].low if i >= 2 else bars[i - 1].low)
            if bars[i].low <= sar:
                is_long = False
                sar = ep
                ep = bars[i].low
                cur_af = af
            else:
                if bars[i].high > ep:
                    ep = bars[i].high
                    cur_af = min(cur_af + af, max_af)
        else:
            sar = max(sar, bars[i - 1].high, bars[i - 2].high if i >= 2 else bars[i - 1].high)
            if bars[i].high >= sar:
                is_long = True
                sar = ep
                ep = bars[i].high
                cur_af = af
            else:
                if bars[i].low < ep:
                    ep = bars[i].low
                    cur_af = min(cur_af + af, max_af)

        sar_list[i] = sar

    return sar_list


# ===== KDJ 计算（与V3回测完全一致） =====

def calc_kdj(bars: List[OHLCV], k_period: int = KDJ_K_PERIOD,
             d_period: int = KDJ_D_PERIOD) -> Tuple[List[float], List[float], List[float]]:
    """计算 KDJ 指标"""
    n = len(bars)
    k_list = [50.0] * n
    d_list = [50.0] * n
    j_list = [50.0] * n

    prev_k = 50.0
    prev_d = 50.0

    for i in range(n):
        start_idx = max(0, i - k_period + 1)
        period_high = max(bars[j].high for j in range(start_idx, i + 1))
        period_low = min(bars[j].low for j in range(start_idx, i + 1))

        if period_high == period_low:
            rsv = 50.0
        else:
            rsv = (bars[i].close - period_low) / (period_high - period_low) * 100.0

        k = (2.0 / 3.0) * prev_k + (1.0 / 3.0) * rsv
        d = (2.0 / 3.0) * prev_d + (1.0 / 3.0) * k
        j = 3.0 * k - 2.0 * d

        k_list[i] = k
        d_list[i] = d
        j_list[i] = j

        prev_k = k
        prev_d = d

    return k_list, d_list, j_list


# ===== 信号检测（与V3回测一致） =====

def detect_sar_reversal(bars: List[OHLCV], sar: List[float]) -> Tuple[List[bool], List[bool]]:
    """检测 SAR 上涨/下跌反转"""
    n = len(bars)
    bull = [False] * n
    bear = [False] * n
    for i in range(1, n):
        prev_state = bars[i - 1].close < sar[i - 1]   # True=空方
        curr_state = bars[i].close < sar[i]             # True=空方
        if prev_state and not curr_state:
            bull[i] = True   # 空转多 → 上涨反转
        if not prev_state and curr_state:
            bear[i] = True   # 多转空 → 下跌反转
    return bull, bear


def detect_sar_reversal_sustained(bars: List[OHLCV], sar: List[float],
                                  sustain_bars: int = SAR_SUSTAIN_BARS) -> Tuple[List[bool], List[bool]]:
    """检测 SAR 反转并持续 N 根 K 线"""
    n = len(bars)
    bull_sustained = [False] * n
    bear_sustained = [False] * n

    for i in range(1, n):
        prev_bear = bars[i - 1].close < sar[i - 1]
        curr_bull = bars[i].close > sar[i]

        if prev_bear and curr_bull:
            if i + sustain_bars < n:
                sustained = all(bars[j].close > sar[j] for j in range(i + 1, i + 1 + sustain_bars))
                if sustained:
                    confirm_idx = i + sustain_bars
                    bull_sustained[confirm_idx] = True

        prev_bull = bars[i - 1].close > sar[i - 1]
        curr_bear = bars[i].close < sar[i]

        if prev_bull and curr_bear:
            if i + sustain_bars < n:
                sustained = all(bars[j].close < sar[j] for j in range(i + 1, i + 1 + sustain_bars))
                if sustained:
                    confirm_idx = i + sustain_bars
                    bear_sustained[confirm_idx] = True

    return bull_sustained, bear_sustained


def detect_kdj_cross(k: List[float], d: List[float]) -> Tuple[List[bool], List[bool]]:
    """检测 KDJ 金叉/死叉"""
    n = len(k)
    golden = [False] * n
    death = [False] * n
    for i in range(1, n):
        if k[i - 1] <= d[i - 1] and k[i] > d[i]:
            golden[i] = True
        if k[i - 1] >= d[i - 1] and k[i] < d[i]:
            death[i] = True
    return golden, death


def build_5m_index_map(bars_1m: List[OHLCV], bars_5m: List[OHLCV]) -> List[int]:
    """为每根 1m K线找到其对应的 5m K线索引"""
    idx_5m = []
    j = 0
    for bar in bars_1m:
        while j + 1 < len(bars_5m) and bars_5m[j + 1].timestamp <= bar.timestamp:
            j += 1
        idx_5m.append(j)
    return idx_5m


# ===== 持仓状态管理 =====

def load_position_state() -> Dict[str, Any]:
    """从JSON文件加载持仓状态"""
    if os.path.exists(POSITION_STATE_PATH):
        try:
            with open(POSITION_STATE_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            print(f"[状态] 读取持仓状态失败: {e}，使用空状态")
    return {"position": None, "cooldown_until": 0}


def save_position_state(state: Dict[str, Any]) -> None:
    """保存持仓状态到JSON文件"""
    os.makedirs(os.path.dirname(POSITION_STATE_PATH), exist_ok=True)
    with open(POSITION_STATE_PATH, "w", encoding="utf-8") as f:
        json.dump(state, f, indent=2, ensure_ascii=False)
    print(f"[状态] 已保存: position={'空仓' if state.get('position') is None else state['position']['side'] + '(' + state['position']['state'] + ')'}")


# ===== 数据获取：数据库 =====

def fetch_db_1m_bars(limit: int = DB_BARS_LOAD) -> List[OHLCV]:
    """从SQLite数据库获取1m K线数据"""
    if not os.path.exists(DB_PATH):
        return []
    try:
        conn = sqlite3.connect(DB_PATH)
        rows = conn.execute(
            "SELECT timestamp, open, high, low, close FROM ohlcv_1m ORDER BY timestamp DESC LIMIT ?",
            (limit,)
        ).fetchall()
        conn.close()
        bars = [OHLCV(r[0], r[1], r[2], r[3], r[4]) for r in reversed(rows)]
        return bars
    except Exception as e:
        print(f"[数据库] 1m数据获取失败: {e}")
        return []


def fetch_db_5m_bars(limit: int = DB_BARS_LOAD) -> List[OHLCV]:
    """从SQLite数据库获取5m K线数据"""
    if not os.path.exists(DB_PATH):
        return []
    try:
        conn = sqlite3.connect(DB_PATH)
        rows = conn.execute(
            "SELECT timestamp, open, high, low, close FROM ohlcv_5m ORDER BY timestamp DESC LIMIT ?",
            (limit,)
        ).fetchall()
        conn.close()
        bars = [OHLCV(r[0], r[1], r[2], r[3], r[4]) for r in reversed(rows)]
        return bars
    except Exception as e:
        print(f"[数据库] 5m数据获取失败: {e}")
        return []


# ===== 数据获取：yfinance =====

def _is_rate_limit_error(e: Exception) -> bool:
    msg = str(e).lower()
    return "rate" in msg or "too many" in msg or "429" in msg


def fetch_yfinance_spot() -> Optional[float]:
    """从 yfinance 获取实时价格"""
    for ticker_name in _YF_TICKERS:
        try:
            ticker = yf.Ticker(ticker_name)
            try:
                price = ticker.fast_info.get("lastPrice") or ticker.fast_info.get("last_price")
                if price is not None and price > 0:
                    print(f"[yfinance] 现货价 ({ticker_name}): {price}")
                    return float(price)
            except Exception:
                pass
            hist = ticker.history(period="1d")
            if not hist.empty:
                price = float(hist.iloc[-1]["Close"])
                if price > 0:
                    print(f"[yfinance] 现货价 ({ticker_name}): {price} [history]")
                    return price
        except Exception as e:
            print(f"[yfinance] 现货价获取失败 ({ticker_name}): {e}")
            if _is_rate_limit_error(e):
                time.sleep(3)
                continue
    return None


def fetch_yfinance_1m(period: str = "5d", min_bars: int = 60) -> Optional[List[OHLCV]]:
    """从 yfinance 获取1m K线"""
    for ticker_name in _YF_TICKERS:
        try:
            ticker = yf.Ticker(ticker_name)
            df = ticker.history(period=period, interval="1m")
            if df is None or df.empty:
                continue
            bars = []
            for idx, row in df.iterrows():
                ts = int(idx.timestamp()) if hasattr(idx, 'timestamp') else int(idx.value / 1e9)
                bars.append(OHLCV(ts, float(row["Open"]), float(row["High"]),
                                   float(row["Low"]), float(row["Close"])))
            if len(bars) >= min_bars:
                print(f"[yfinance] 1m: {len(bars)} 根 ({ticker_name})")
                return bars
        except Exception as e:
            print(f"[yfinance] 1m获取失败 ({ticker_name}): {e}")
            if _is_rate_limit_error(e):
                time.sleep(3)
    return None


def fetch_yfinance_5m(period: str = "5d", min_bars: int = 48) -> Optional[List[OHLCV]]:
    """从 yfinance 获取5m K线"""
    for ticker_name in _YF_TICKERS:
        try:
            ticker = yf.Ticker(ticker_name)
            df = ticker.history(period=period, interval="5m")
            if df is None or df.empty:
                continue
            bars = []
            for idx, row in df.iterrows():
                ts = int(idx.timestamp()) if hasattr(idx, 'timestamp') else int(idx.value / 1e9)
                bars.append(OHLCV(ts, float(row["Open"]), float(row["High"]),
                                   float(row["Low"]), float(row["Close"])))
            if len(bars) >= min_bars:
                print(f"[yfinance] 5m: {len(bars)} 根 ({ticker_name})")
                return bars
        except Exception as e:
            print(f"[yfinance] 5m获取失败 ({ticker_name}): {e}")
            if _is_rate_limit_error(e):
                time.sleep(3)
    return None


# ===== 数据获取：xaus.com =====

def fetch_xaus_spot() -> Optional[float]:
    """从 xaus.com 获取实时现货价"""
    try:
        resp = requests.get(XAUS_SPOT_URL, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        price = data.get("spot_usd_oz") or data.get("xau", {}).get("price")
        if price is not None:
            return float(price)
    except Exception as e:
        print(f"[xaus.com] 现货价获取失败: {e}")
    return None


def fetch_xaus_intraday(hours: int = 48) -> pd.DataFrame:
    """获取日内2分钟采样数据"""
    try:
        resp = requests.get(XAUS_INTRADAY_URL, params={"symbol": "xau", "hours": hours}, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        points = data.get("points", [])
        if not points:
            return pd.DataFrame(columns=["price"])

        records = []
        for pt in points:
            ts = pt.get("t")
            p = pt.get("p")
            if ts is not None and p is not None:
                dt = datetime.fromtimestamp(ts, tz=timezone.utc)
                records.append({"datetime": dt, "price": float(p)})

        if not records:
            return pd.DataFrame(columns=["price"])

        df = pd.DataFrame(records)
        df = df.set_index("datetime").sort_index()
        df = df[~df.index.duplicated(keep="last")]
        return df
    except Exception as e:
        print(f"[xaus.com] 日内数据获取失败: {e}")
        return pd.DataFrame(columns=["price"])


def resample_to_ohlc_bars(intraday_df: pd.DataFrame, rule: str) -> List[OHLCV]:
    """将2分钟采样价格重采样为指定周期的 OHLCV 列表"""
    if intraday_df.empty:
        return []
    ohlc = intraday_df["price"].resample(rule).agg({
        "open": "first", "high": "max", "low": "min", "close": "last"
    }).dropna(subset=["close"])
    bars = []
    for idx, row in ohlc.iterrows():
        ts = int(idx.timestamp()) if hasattr(idx, 'timestamp') else int(idx.value / 1e9)
        bars.append(OHLCV(ts, float(row["open"]), float(row["high"]),
                           float(row["low"]), float(row["close"])))
    return bars


# ===== 休市判断 =====

def _is_us_dst(dt_bj: datetime) -> bool:
    year = dt_bj.year
    mar8 = datetime(year, 3, 8)
    dst_start = datetime(year, 3, 8 + (6 - mar8.weekday()) % 7, 14, 0)
    nov1 = datetime(year, 11, 1)
    dst_end = datetime(year, 11, 1 + (6 - nov1.weekday()) % 7, 15, 0)
    return dst_start <= dt_bj < dst_end


def _check_market_closed(now_bj: Optional[datetime] = None) -> Tuple[bool, str, Optional[datetime]]:
    if now_bj is None:
        now_bj = datetime.now(BJ_TZ).replace(tzinfo=None)
    elif now_bj.tzinfo is not None:
        now_bj = now_bj.astimezone(BJ_TZ).replace(tzinfo=None)

    # 节假日
    date_str = now_bj.strftime("%Y-%m-%d")
    year = now_bj.year
    holidays = _HOLIDAYS.get(year, {})
    if now_bj.month == 1:
        holidays.update(_HOLIDAYS.get(year - 1, {}))

    if date_str in holidays:
        holiday_name = holidays[date_str]
        next_open = _find_next_open(now_bj, days_ahead=1)
        return True, f"节假日休市（{holiday_name}）", next_open

    # 周末
    is_dst = _is_us_dst(now_bj)
    sat_close_h = 5 if is_dst else 6
    mon_open_h = 6 if is_dst else 7
    weekday = now_bj.weekday()

    if weekday == 5 and now_bj.hour >= sat_close_h:
        next_monday = now_bj + timedelta(days=2)
        return True, "周末休市", next_monday.replace(hour=mon_open_h, minute=0, second=0, microsecond=0)
    elif weekday == 6:
        next_monday = now_bj + timedelta(days=1)
        return True, "周末休市", next_monday.replace(hour=mon_open_h, minute=0, second=0, microsecond=0)
    elif weekday == 0 and now_bj.hour < mon_open_h:
        return True, "周末休市（周一开盘前）", now_bj.replace(hour=mon_open_h, minute=0, second=0, microsecond=0)

    return False, "", None


def _find_next_open(now_bj: datetime, days_ahead: int = 1) -> datetime:
    is_dst = _is_us_dst(now_bj)
    mon_open_h = 6 if is_dst else 7
    candidate = now_bj + timedelta(days=days_ahead)
    while candidate.weekday() >= 5:
        candidate += timedelta(days=1)
    for _ in range(30):
        date_str = candidate.strftime("%Y-%m-%d")
        year = candidate.year
        if date_str in _HOLIDAYS.get(year, {}):
            candidate += timedelta(days=1)
            while candidate.weekday() >= 5:
                candidate += timedelta(days=1)
            continue
        break
    return candidate.replace(hour=mon_open_h, minute=0, second=0, microsecond=0)


# ===== 图表生成 =====

def generate_chart(bars_1m: List[OHLCV], sar_1m: List[float],
                   k_1m: List[float], d_1m: List[float],
                   position_state: Dict[str, Any],
                   chart_path: str) -> str:
    """生成K线+SAR+KDJ图表"""
    os.makedirs(os.path.dirname(chart_path), exist_ok=True)

    n = len(bars_1m)
    # 只显示最近120根K线
    show_n = min(120, n)
    start = n - show_n

    dates = [datetime.fromtimestamp(bars_1m[i].timestamp) for i in range(start, n)]
    opens = [bars_1m[i].open for i in range(start, n)]
    highs = [bars_1m[i].high for i in range(start, n)]
    lows = [bars_1m[i].low for i in range(start, n)]
    closes = [bars_1m[i].close for i in range(start, n)]
    sar_vals = [sar_1m[i] for i in range(start, n)]
    k_vals = [k_1m[i] for i in range(start, n)]
    d_vals = [d_1m[i] for i in range(start, n)]

    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(16, 10),
                                     gridspec_kw={"height_ratios": [3, 1]},
                                     sharex=True)
    fig.suptitle("XAU/USD 1m SAR+KDJ Monitor (V3 Strategy)", fontsize=14, fontweight="bold")

    # 主图：K线 + SAR
    x = range(len(dates))
    for i in range(len(dates)):
        color = "#e74c3c" if closes[i] < opens[i] else "#2ecc71"
        ax1.plot([i, i], [lows[i], highs[i]], color=color, linewidth=0.8)
        ax1.plot([i, i], [opens[i], closes[i]], color=color, linewidth=2.5)

    # SAR点
    ax1.scatter(x, sar_vals, s=8, c="#3498db", alpha=0.7, zorder=5, label="SAR")

    # 标注持仓
    pos = position_state.get("position")
    if pos is not None:
        entry_price = pos["entry_price"]
        side_label = "LONG" if pos["side"] == "long" else "SHORT"
        state_label = "FULL" if pos["state"] == "full" else "HALF"
        ax1.axhline(y=entry_price, color="gold", linestyle="--", linewidth=1.2,
                     label=f"Entry {side_label}@{entry_price:.1f} ({state_label})")

    ax1.set_ylabel("Price (USD/oz)")
    ax1.legend(loc="upper left", fontsize=9)
    ax1.grid(True, alpha=0.3)
    ax1.set_xticks(x[::10])
    ax1.set_xticklabels([dates[i].strftime("%H:%M") for i in range(0, len(dates), 10)],
                         fontsize=8, rotation=45)

    # 副图：KDJ
    ax2.plot(x, k_vals, label="K", color="#e74c3c", linewidth=1)
    ax2.plot(x, d_vals, label="D", color="#2ecc71", linewidth=1)
    ax2.axhline(y=80, color="gray", linestyle=":", linewidth=0.8)
    ax2.axhline(y=20, color="gray", linestyle=":", linewidth=0.8)
    ax2.set_ylabel("KDJ")
    ax2.set_xlabel("Time")
    ax2.legend(loc="upper left", fontsize=9)
    ax2.grid(True, alpha=0.3)

    plt.tight_layout()
    plt.savefig(chart_path, dpi=150)
    plt.close()
    print(f"[图表] 已保存: {chart_path}")
    return chart_path


# ===== 格式化工具 =====

def fmt_price(v: float) -> str:
    return f"${v:,.2f}"


def fmt_delta(v: float) -> str:
    if v >= 0:
        return f"+{v:.1f}"
    return f"{v:.1f}"


# ===== 主逻辑 =====

def main() -> None:
    result_mode_raw = sys.argv[1] if len(sys.argv) > 1 else "auto"
    stop_loss_pts = float(sys.argv[2]) if len(sys.argv) > 2 else STOP_LOSS_POINTS
    floating_loss_warn = float(sys.argv[3]) if len(sys.argv) > 3 else FLOATING_LOSS_WARN

    print(f"[参数] result_mode={result_mode_raw}, stop_loss={stop_loss_pts}, floating_loss_warn={floating_loss_warn}")
    print(f"[路径] DB={DB_PATH} | STATE={POSITION_STATE_PATH} | CHART={CHART_DIR}")

    try:
        mode = (result_mode_raw or "auto").strip().lower()
        if mode not in {"auto", "display_only", "notify", "no_reply"}:
            raise ValueError("result_mode 只能是 auto / display_only / notify / no_reply")

        # ===== 0. 休市判断 =====
        is_closed, closed_reason, next_open = _check_market_closed()
        if is_closed:
            next_open_str = next_open.strftime("%Y-%m-%d %H:%M") if next_open else "未知"
            print(f"[休市] {closed_reason}，下一开盘时间：{next_open_str}")
            return

        # ===== 1. 加载持仓状态 =====
        pos_state = load_position_state()
        # 确保状态文件存在（首次运行时创建）
        if not os.path.exists(POSITION_STATE_PATH):
            save_position_state(pos_state)
        position = pos_state.get("position")
        cooldown_until = pos_state.get("cooldown_until", 0)
        now_ts = int(time.time())

        if position:
            print(f"[持仓] {'多' if position['side'] == 'long' else '空'}单 "
                  f"{'全仓' if position['state'] == 'full' else '半仓'} "
                  f"入场价={position['entry_price']:.1f} "
                  f"入场时间={datetime.fromtimestamp(position['entry_time']).strftime('%Y-%m-%d %H:%M')}")
        else:
            print(f"[持仓] 空仓")

        if cooldown_until > now_ts:
            remaining = cooldown_until - now_ts
            print(f"[冷却] 冷却中，剩余 {remaining} 秒")
        else:
            cooldown_until = 0

        # ===== 2. 获取K线数据 =====
        # 优先数据库，备用yfinance/xaus.com
        bars_1m = fetch_db_1m_bars(DB_BARS_LOAD)
        bars_5m = fetch_db_5m_bars(DB_BARS_LOAD)

        data_source_1m = f"db({len(bars_1m)})"
        data_source_5m = f"db({len(bars_5m)})"

        # 数据库数据不足时，尝试yfinance
        if len(bars_1m) < 60:
            print("[数据] 数据库1m数据不足，尝试yfinance...")
            yf_1m = fetch_yfinance_1m()
            if yf_1m:
                bars_1m = yf_1m
                data_source_1m = f"yfinance({len(bars_1m)})"

        if len(bars_5m) < 48:
            print("[数据] 数据库5m数据不足，尝试yfinance...")
            yf_5m = fetch_yfinance_5m()
            if yf_5m:
                bars_5m = yf_5m
                data_source_5m = f"yfinance({len(bars_5m)})"

        # yfinance也失败，尝试xaus.com
        if len(bars_1m) < 30 or len(bars_5m) < 20:
            print("[数据] yfinance也不足，尝试xaus.com...")
            intraday_df = fetch_xaus_intraday(hours=48)
            if not intraday_df.empty:
                if len(bars_1m) < 30:
                    xaus_1m = resample_to_ohlc_bars(intraday_df, "1min")
                    if len(xaus_1m) > len(bars_1m):
                        bars_1m = xaus_1m
                        data_source_1m = f"xaus.com({len(bars_1m)})"
                if len(bars_5m) < 20:
                    xaus_5m = resample_to_ohlc_bars(intraday_df, "5min")
                    if len(xaus_5m) > len(bars_5m):
                        bars_5m = xaus_5m
                        data_source_5m = f"xaus.com({len(bars_5m)})"

        print(f"[数据] 1m: {data_source_1m} | 5m: {data_source_5m}")

        # 数据最低要求
        if len(bars_1m) < 20 or len(bars_5m) < 15:
            raise RuntimeError(f"K线数据严重不足: 1m={len(bars_1m)}, 5m={len(bars_5m)}")

        # ===== 3. 获取实时现货价 =====
        spot_price = None
        # 从数据库最新K线提取
        if bars_1m:
            spot_price = bars_1m[-1].close
            db_latest_time = datetime.fromtimestamp(bars_1m[-1].timestamp).strftime("%Y-%m-%d %H:%M")
            print(f"[价格] 数据库最新价: {spot_price} ({db_latest_time})")

        # 检查数据库数据时效性：如果最新K线超过5分钟，获取实时价格补充
        data_age = now_ts - bars_1m[-1].timestamp if bars_1m else 999
        if data_age > 300:  # 超过5分钟
            print(f"[价格] 数据库数据已过期({data_age}秒)，获取实时价格...")
            # yfinance
            yf_price = fetch_yfinance_spot()
            if yf_price:
                spot_price = yf_price
            else:
                # xaus.com
                xaus_price = fetch_xaus_spot()
                if xaus_price:
                    spot_price = xaus_price

        if spot_price is None:
            raise RuntimeError("无法获取当前价格")

        print(f"[价格] 当前价: {fmt_price(spot_price)}")

        # ===== 4. 计算指标 =====
        sar_1m = calc_sar(bars_1m)
        sar_5m = calc_sar(bars_5m)
        k_1m, d_1m, j_1m = calc_kdj(bars_1m)
        print("[指标] SAR + KDJ 计算完成")

        # ===== 5. 信号检测 =====
        # 1m信号
        bull_rev_1m, bear_rev_1m = detect_sar_reversal(bars_1m, sar_1m)
        golden_kdj, death_kdj = detect_kdj_cross(k_1m, d_1m)
        bull_sustained_1m, bear_sustained_1m = detect_sar_reversal_sustained(bars_1m, sar_1m)

        # 5m信号
        bull_rev_5m, bear_rev_5m = detect_sar_reversal(bars_5m, sar_5m)

        # 1m→5m索引映射
        idx_5m = build_5m_index_map(bars_1m, bars_5m)

        n_1m = len(bars_1m)
        # 只检查最近CONFIRM_WINDOW根1m K线的信号
        w_start = max(0, n_1m - CONFIRM_WINDOW)

        # 最近窗口内的信号
        has_1m_bull = any(bull_rev_1m[w] for w in range(w_start, n_1m))
        has_1m_bear = any(bear_rev_1m[w] for w in range(w_start, n_1m))
        has_kdj_golden = any(golden_kdj[w] for w in range(w_start, n_1m))
        has_kdj_death = any(death_kdj[w] for w in range(w_start, n_1m))
        has_5m_bull = any(bull_rev_5m[idx_5m[w]] for w in range(w_start, n_1m))
        has_5m_bear = any(bear_rev_5m[idx_5m[w]] for w in range(w_start, n_1m))
        has_bear_sustained = any(bear_sustained_1m[w] for w in range(w_start, n_1m))
        has_bull_sustained = any(bull_sustained_1m[w] for w in range(w_start, n_1m))

        # SAR趋势（当前K线）
        last_1m = bars_1m[-1]
        sar_trend_1m = "bull" if last_1m.close > sar_1m[-1] else "bear"
        last_5m = bars_5m[-1]
        sar_trend_5m = "bull" if last_5m.close > sar_5m[-1] else "bear"

        # KDJ状态
        kdj_state = "golden" if has_kdj_golden else ("death" if has_kdj_death else "neutral")
        k_val = k_1m[-1]
        d_val = d_1m[-1]
        j_val = j_1m[-1]

        print(f"[信号] 1m SAR趋势={sar_trend_1m} | 5m SAR趋势={sar_trend_5m} | KDJ={kdj_state}(K={k_val:.1f},D={d_val:.1f},J={j_val:.1f})")
        print(f"[信号] 窗口内: 1m_bull={has_1m_bull} 1m_bear={has_1m_bear} kdj_golden={has_kdj_golden} kdj_death={has_kdj_death} 5m_bull={has_5m_bull} 5m_bear={has_5m_bear}")
        print(f"[信号] 持续反转: bear_sustained={has_bear_sustained} bull_sustained={has_bull_sustained}")

        # ===== 6. 交易判断 =====
        action = "空仓观望"
        trigger_reason = ""
        current_price = spot_price
        closed_pnl = None  # 平仓时的盈亏（仅平仓操作时有值）

        if position is not None:
            # === 有持仓 ===
            entry_price = position["entry_price"]
            side = position["side"]
            state = position["state"]

            # 计算浮盈/浮亏（点数）
            if side == "long":
                floating_pnl = current_price - entry_price
            else:
                floating_pnl = entry_price - current_price

            # ① 止损检查（最高优先级）
            if floating_pnl <= -stop_loss_pts:
                action = "止损平仓"
                trigger_reason = f"浮亏 {abs(floating_pnl):.1f} 点 >= 止损线 {stop_loss_pts:.0f} 点"
                closed_pnl = floating_pnl
                # 全仓平仓
                pos_state["position"] = None
                pos_state["cooldown_until"] = now_ts + COOLDOWN_BARS * 60
                save_position_state(pos_state)

            # ② 5m SAR反转 → 全部平仓
            elif side == "long" and has_5m_bear:
                action = "全部平仓"
                trigger_reason = "5m SAR下跌反转"
                closed_pnl = floating_pnl
                pos_state["position"] = None
                pos_state["cooldown_until"] = now_ts + COOLDOWN_BARS * 60
                save_position_state(pos_state)

            elif side == "short" and has_5m_bull:
                action = "全部平仓"
                trigger_reason = "5m SAR上涨反转"
                closed_pnl = floating_pnl
                pos_state["position"] = None
                pos_state["cooldown_until"] = now_ts + COOLDOWN_BARS * 60
                save_position_state(pos_state)

            # ③ 半仓减仓（仅全仓状态）
            elif state == "full":
                if side == "long" and has_bear_sustained and has_kdj_death:
                    action = "半仓减仓"
                    trigger_reason = "1m SAR下跌反转持续3根 + KDJ死叉"
                    position["state"] = "half"
                    position["half_exit_price"] = current_price
                    position["half_exit_time"] = now_ts
                    pos_state["position"] = position
                    save_position_state(pos_state)

                elif side == "short" and has_bull_sustained and has_kdj_golden:
                    action = "半仓减仓"
                    trigger_reason = "1m SAR上涨反转持续3根 + KDJ金叉"
                    position["state"] = "half"
                    position["half_exit_price"] = current_price
                    position["half_exit_time"] = now_ts
                    pos_state["position"] = position
                    save_position_state(pos_state)

                else:
                    action = "继续持仓"
                    trigger_reason = f"1m SAR={sar_trend_1m} 5m SAR={sar_trend_5m} KDJ={kdj_state}"
            else:
                # 半仓状态，无5m信号，继续持有
                action = "继续持仓"
                trigger_reason = f"半仓等待5m信号 | 1m SAR={sar_trend_1m} 5m SAR={sar_trend_5m}"

        else:
            # === 无持仓 ===
            floating_pnl = 0.0

            # 冷却期检查
            if cooldown_until > now_ts:
                action = "空仓观望"
                trigger_reason = f"冷却中（剩余 {cooldown_until - now_ts} 秒）"
            else:
                # 进仓条件检查
                # 做多: 1m SAR上涨反转 + 1m KDJ金叉 + 5m SAR上涨反转
                if has_1m_bull and has_kdj_golden and has_5m_bull:
                    action = "进仓做多"
                    trigger_reason = "1m SAR上涨反转 + 1m KDJ金叉 + 5m SAR上涨反转"
                    pos_state["position"] = {
                        "side": "long",
                        "entry_price": current_price,
                        "entry_time": now_ts,
                        "state": "full",
                        "half_exit_price": None,
                        "half_exit_time": None,
                    }
                    pos_state["cooldown_until"] = 0
                    save_position_state(pos_state)

                # 做空: 1m SAR下跌反转 + 1m KDJ死叉 + 5m SAR下跌反转
                elif has_1m_bear and has_kdj_death and has_5m_bear:
                    action = "进仓做空"
                    trigger_reason = "1m SAR下跌反转 + 1m KDJ死叉 + 5m SAR下跌反转"
                    pos_state["position"] = {
                        "side": "short",
                        "entry_price": current_price,
                        "entry_time": now_ts,
                        "state": "full",
                        "half_exit_price": None,
                        "half_exit_time": None,
                    }
                    pos_state["cooldown_until"] = 0
                    save_position_state(pos_state)

                else:
                    action = "空仓观望"
                    trigger_reason = f"1m SAR={sar_trend_1m} 5m SAR={sar_trend_5m} KDJ={kdj_state} (三条件未共振)"

        # 重新读取position（可能已更新）
        position = pos_state.get("position")

        # 计算当前浮盈/浮亏
        if position is not None:
            if position["side"] == "long":
                floating_pnl = current_price - position["entry_price"]
            else:
                floating_pnl = position["entry_price"] - current_price
        elif closed_pnl is not None:
            # 刚平仓，使用平仓时的盈亏
            floating_pnl = closed_pnl
        else:
            floating_pnl = 0.0

        print(f"[操作] {action} | 原因: {trigger_reason} | 浮盈亏: {fmt_delta(floating_pnl)} 点")

        # ===== 7. 生成图表 =====
        chart_path = os.path.join(CHART_DIR, "xauusd_monitor.png")
        try:
            generate_chart(bars_1m, sar_1m, k_1m, d_1m, pos_state, chart_path)
        except Exception as e:
            print(f"[图表] 生成失败: {e}")
            chart_path = ""

        # ===== 8. 决定 result_mode =====
        is_action = action in ("进仓做多", "进仓做空", "半仓减仓", "全部平仓", "止损平仓")
        is_large_loss = (position is not None and floating_pnl <= -floating_loss_warn)

        if mode == "auto":
            if is_action:
                actual_mode = "display_only"
            elif is_large_loss:
                actual_mode = "display_only"
            else:
                actual_mode = "no_reply"
        else:
            actual_mode = mode

        # ===== 9. 构建消息 =====
        # 持仓状态描述
        if position is None:
            pos_desc = "空仓"
        else:
            side_cn = "多单" if position["side"] == "long" else "空单"
            state_cn = "全仓" if position["state"] == "full" else "半仓"
            pos_desc = f"{side_cn}{state_cn}"

        message_parts = [
            f"黄金V3策略监控",
            "",
            f"当前价格：{fmt_price(current_price)}/盎司",
            f"持仓状态：{pos_desc}",
            f"本轮操作：{action}",
        ]

        if trigger_reason:
            message_parts.append(f"触发条件：{trigger_reason}")

        if position is not None:
            pnl_emoji = "📈" if floating_pnl >= 0 else "📉"
            message_parts.append(f"{pnl_emoji} 浮盈/浮亏：{fmt_delta(floating_pnl)} 点")
        elif action in ("全部平仓", "止损平仓") and closed_pnl is not None:
            pnl_emoji = "📈" if closed_pnl >= 0 else "📉"
            message_parts.append(f"{pnl_emoji} 平仓盈亏：{fmt_delta(closed_pnl)} 点")

        # 指标状态
        message_parts.append("")
        message_parts.append(f"指标状态：1m SAR={sar_trend_1m} | 5m SAR={sar_trend_5m} | KDJ K={k_val:.1f} D={d_val:.1f} J={j_val:.1f}")

        # 数据源
        message_parts.append(f"数据源：1m={data_source_1m} | 5m={data_source_5m}")

        # 时间戳
        message_parts.append(f"时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        # 图表链接（通过 nginx 暴露的 URL）
        if chart_path and os.path.exists(chart_path):
            chart_url = CHART_URL_PREFIX.rstrip("/") + "/" + os.path.basename(chart_path)
            message_parts.append(f"\n[K线图表]({chart_url})")

        message = "\n".join(message_parts)

        # 浮亏预警标记
        push_title = "黄金V3策略监控"
        if is_large_loss and not is_action:
            push_title = "黄金V3策略监控 - 浮亏预警"

        # ===== 10. 决定是否推送 =====
        data_dict = {
            "current_price": current_price,
            "action": action,
            "trigger_reason": trigger_reason,
            "position": position,
            "floating_pnl": round(floating_pnl, 2),
            "is_action": is_action,
            "is_large_loss": is_large_loss,
            "cooldown_until": pos_state.get("cooldown_until", 0),
            "sar_trend_1m": sar_trend_1m,
            "sar_trend_5m": sar_trend_5m,
            "kdj_k": round(k_val, 2),
            "kdj_d": round(d_val, 2),
            "kdj_j": round(j_val, 2),
        }
        if chart_path:
            data_dict["chart_path"] = chart_path

        # actual_mode 决策：
        #   auto + 主动操作/浮亏预警 → 推送
        #   auto + 继续持仓/空仓观望 → 静默
        #   notify / display_only → 强制推送
        #   no_reply → 静默
        should_push = (
            actual_mode == "notify"
            or actual_mode == "display_only"
            or (actual_mode == "auto" and (is_action or is_large_loss))
        ) and actual_mode != "no_reply"

        if should_push:
            serverchan_push(push_title, message)
        else:
            print(f"[静默] mode={actual_mode} action={action} is_action={is_action} is_large_loss={is_large_loss}")

        print(f"[完成] {data_dict}")

    except Exception as e:
        err_msg = f"[错误] {e}\n{traceback.format_exc()}"
        print(err_msg)
        # 错误也推送一下，方便排查
        serverchan_push("黄金V3监控异常", f"```\n{err_msg[-2000:]}\n```")


if __name__ == "__main__":
    main()
