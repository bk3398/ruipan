#!/bin/bash
# 锐盘黄金监控 VPS 一键部署脚本
# 在 VPS（root 用户）上执行：bash deploy.sh
set -e

GOLD_DIR=/opt/ruipan/gold
SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
SENDKEY="${SERVERCHAN_SENDKEY:-__SENDKEY_PLACEHOLDER__}"

echo "[1/6] 创建目录 $GOLD_DIR ..."
mkdir -p "$GOLD_DIR/charts"

echo "[2/6] 拷贝文件 ..."
cp "$SRC_DIR"/*.py "$GOLD_DIR/"
cp "$SRC_DIR"/*.sh "$GOLD_DIR/"
if [ -f "$SRC_DIR/gold_data.db" ]; then cp "$SRC_DIR/gold_data.db" "$GOLD_DIR/"; fi
if [ -f "$SRC_DIR/monitor_position_state.json" ]; then cp "$SRC_DIR/monitor_position_state.json" "$GOLD_DIR/"; fi
chmod +x "$GOLD_DIR"/*.sh "$GOLD_DIR"/*.py

echo "[3/6] 注入 SENDKEY 和隧道地址到 wrapper ..."
# 自动获取当前 cloudflared 临时隧道地址
TUNNEL_URL=$(grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' /var/log/cf-quick.log 2>/dev/null | head -1)
if [ -z "$TUNNEL_URL" ]; then
    TUNNEL_URL="http://127.0.0.1"
    echo "  ⚠ 未找到 cloudflared 隧道地址，图表URL使用 $TUNNEL_URL"
else
    echo "  隧道地址：$TUNNEL_URL"
fi
sed -i "s|__SENDKEY_PLACEHOLDER__|$SENDKEY|g" "$GOLD_DIR/ruipan_gold_wrapper.sh"
sed -i "s|__CHART_URL_PLACEHOLDER__|$TUNNEL_URL|g" "$GOLD_DIR/ruipan_gold_wrapper.sh"

echo "[4/6] 安装 Python 依赖 ..."
/usr/bin/python3 -m pip install --quiet --upgrade pip
/usr/bin/python3 -m pip install --quiet pandas numpy matplotlib requests yfinance 2>&1 | tail -3 || true

echo "[5/6] 配置 nginx /static/gold/ 映射 ..."
NGINX_CONF=/etc/nginx/sites-available/ruipan
if [ -f "$NGINX_CONF" ]; then
    if ! grep -q "location /static/gold" "$NGINX_CONF"; then
        # 在 server 块的最后一个 } 之前插入
        sed -i "/^}/i\\    location /static/gold/ {\\n        alias $GOLD_DIR/charts/;\\n        autoindex off;\\n        expires 1m;\\n        add_header Cache-Control \\\"public, max-age=60\\\";\\n    }" "$NGINX_CONF"
        nginx -t && systemctl reload nginx
        echo "  nginx 配置已更新并重载"
    else
        echo "  nginx 已存在 /static/gold 配置，跳过"
    fi
else
    echo "  未找到 $NGINX_CONF，手动添加 nginx 配置"
fi

echo "[6/6] 写入 cron ..."
# 数据采集每 2 分钟，监控每 5 分钟（仅交易时段，wrapper 内判断）
# 开机后等待 cloudflared 启动，自动更新隧道地址到 wrapper
( crontab -l 2>/dev/null | grep -v ruipan_gold_wrapper | grep -v 'gold_update_tunnel'; \
  echo "*/2 * * * * $GOLD_DIR/ruipan_gold_wrapper.sh collect"; \
  echo "*/5 * * * * $GOLD_DIR/ruipan_gold_wrapper.sh monitor"; \
  echo "@reboot sleep 15 && TURL=\$(grep -oE 'https://[a-z0-9-]+\.trycloudflare\.com' /var/log/cf-quick.log 2>/dev/null | head -1) && [ -n \"\$TURL\" ] && sed -i \"s|^export RUIPAN_GOLD_CHART_URL=.*|export RUIPAN_GOLD_CHART_URL=\\\"\$TURL\\\"|\" $GOLD_DIR/ruipan_gold_wrapper.sh # gold_update_tunnel"; \
) | crontab -

touch /var/log/ruipan_gold.log
echo "========================================"
echo "部署完成！"
echo "目录：$GOLD_DIR"
echo "日志：/var/log/ruipan_gold.log"
echo "crontab："
crontab -l | grep ruipan_gold
echo "========================================"
echo "手动验证："
echo "  $GOLD_DIR/ruipan_gold_wrapper.sh collect"
echo "  $GOLD_DIR/ruipan_gold_wrapper.sh monitor"
