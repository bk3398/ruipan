#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""黄金XAU/USD数据采集 VPS 独立版（去除Coze SDK依赖）。

部署路径：/opt/ruipan/gold/
- 定时运行（cron 每 2 分钟一次交易时段），增量采集 1m 数据并聚合
- 数据源优先级：yfinance GC=F → xaus.com intraday → xaus.com history
- INSERT OR IGNORE 自动去重
- 从 1m 聚合 5m/10m/15m/1h

用法：
  python3 gold_data_collector_vps.py           # 增量采集
  python3 gold_data_collector_vps.py --backfill  # 全量历史回填
"""

import json
import math
import os
import re
import sqlite3
import sys
import time
import traceback
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Tuple

import requests

# yfinance 运行时检测安装
try:
    import yfinance as yf
except ImportError:
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "yfinance", "-q"])
    import yfinance as yf


# ===== 路径常量（VPS） =====
_BASE_DIR = os.environ.get("RUIPAN_GOLD_DIR", "/opt/ruipan/gold")
DB_PATH = os.path.join(_BASE_DIR, "gold_data.db")
SYMBOL = "GC=F"

# xaus.com API endpoints
XAUS_SPOT_URL = "https://xaus.com/api/v1/spot"
XAUS_INTRADAY_URL = "https://xaus.com/api/v1/intraday"
XAUS_HISTORY_URL = "https://xaus.com/api/v1/history"

AGGREGATE_MAP = {
    "5m": 5,
    "10m": 10,
    "15m": 15,
    "1h": 60,
}


# ===== 数据库操作 =====

def init_db(db_path: str = DB_PATH) -> sqlite3.Connection:
    """初始化数据库，创建所有表。"""
    os.makedirs(os.path.dirname(db_path), exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")

    # 分钟级OHLCV数据（核心表）
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ohlcv_1m (
            timestamp INTEGER NOT NULL,
            open REAL, high REAL, low REAL, close REAL,
            volume REAL,
            source TEXT,
            PRIMARY KEY (timestamp)
        )
    """)

    # 日线OHLCV数据（从xaus.com历史API获取）
    conn.execute("""
        CREATE TABLE IF NOT EXISTS ohlcv_1d (
            timestamp INTEGER PRIMARY KEY,
            open REAL, high REAL, low REAL, close REAL, volume REAL
        )
    """)

    # 派生周期表（从1m聚合）
    for tf_name in ["5m", "10m", "15m", "1h"]:
        conn.execute(f"""
            CREATE TABLE IF NOT EXISTS ohlcv_{tf_name} (
                timestamp INTEGER PRIMARY KEY,
                open REAL, high REAL, low REAL, close REAL, volume REAL
            )
        """)

    conn.commit()
    return conn


def get_db_stats(conn: sqlite3.Connection) -> Dict[str, int]:
    """获取各表的数据量统计。"""
    stats = {}
    for tf in ["1m", "5m", "10m", "15m", "1h", "1d"]:
        try:
            count = conn.execute(f"SELECT COUNT(*) FROM ohlcv_{tf}").fetchone()[0]
            stats[tf] = count
        except Exception:
            stats[tf] = 0
    return stats


def get_latest_timestamp(conn: sqlite3.Connection, table: str = "ohlcv_1m") -> Optional[int]:
    """获取表中最新数据的时间戳。"""
    row = conn.execute(f"SELECT MAX(timestamp) FROM {table}").fetchone()
    return row[0]


def insert_1m_data(conn: sqlite3.Connection, rows: List[Tuple], source: str = "yfinance") -> int:
    """插入1m数据，自动去重，返回实际新增条数。"""
    if not rows:
        return 0
    before = conn.execute("SELECT COUNT(*) FROM ohlcv_1m").fetchone()[0]
    conn.executemany(
        "INSERT OR IGNORE INTO ohlcv_1m (timestamp, open, high, low, close, volume, source) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [(r[0], r[1], r[2], r[3], r[4], r[5], source) for r in rows],
    )
    conn.commit()
    after = conn.execute("SELECT COUNT(*) FROM ohlcv_1m").fetchone()[0]
    return after - before


def insert_1d_data(conn: sqlite3.Connection, rows: List[Tuple]) -> int:
    """插入日线数据，自动去重，返回实际新增条数。"""
    if not rows:
        return 0
    before = conn.execute("SELECT COUNT(*) FROM ohlcv_1d").fetchone()[0]
    conn.executemany(
        "INSERT OR IGNORE INTO ohlcv_1d (timestamp, open, high, low, close, volume) VALUES (?, ?, ?, ?, ?, ?)",
        rows,
    )
    conn.commit()
    after = conn.execute("SELECT COUNT(*) FROM ohlcv_1d").fetchone()[0]
    return after - before


def aggregate_1m_to_tf(conn: sqlite3.Connection, tf_name: str, tf_minutes: int) -> int:
    """从1m数据聚合到指定周期，返回新增条数。"""
    table = f"ohlcv_{tf_name}"

    # 获取该周期表已有的最新时间戳
    latest = conn.execute(f"SELECT MAX(timestamp) FROM {table}").fetchone()[0]

    # 获取1m数据的时间范围
    min_ts = conn.execute("SELECT MIN(timestamp) FROM ohlcv_1m").fetchone()[0]
    if min_ts is None:
        return 0

    # 从已有最新时间戳开始（或从头开始），回退一个周期确保完整性
    start_ts = (latest if latest else min_ts) - tf_minutes * 60

    # 获取需要聚合的1m数据
    rows = conn.execute(
        "SELECT timestamp, open, high, low, close, volume FROM ohlcv_1m WHERE timestamp >= ? ORDER BY timestamp",
        (start_ts,),
    ).fetchall()

    if not rows:
        return 0

    # 按周期分组聚合
    groups: Dict[int, List[Tuple]] = {}
    for row in rows:
        ts = row[0]
        period_start = (ts // (tf_minutes * 60)) * (tf_minutes * 60)
        if period_start not in groups:
            groups[period_start] = []
        groups[period_start].append(row)

    aggregated = []
    for period_start, candles in sorted(groups.items()):
        opens = [c[1] for c in candles if c[1] is not None]
        highs = [c[2] for c in candles if c[2] is not None]
        lows = [c[3] for c in candles if c[3] is not None]
        closes = [c[4] for c in candles if c[4] is not None]
        volumes = [c[5] for c in candles if c[5] is not None]

        if not opens:
            continue

        agg_open = opens[0]
        agg_high = max(highs)
        agg_low = min(lows)
        agg_close = closes[-1]
        agg_volume = sum(volumes) if volumes else None

        aggregated.append((period_start, agg_open, agg_high, agg_low, agg_close, agg_volume))

    if not aggregated:
        return 0

    before = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
    conn.executemany(
        f"INSERT OR IGNORE INTO {table} (timestamp, open, high, low, close, volume) VALUES (?, ?, ?, ?, ?, ?)",
        aggregated,
    )
    conn.commit()
    after = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
    return after - before


# ===== yfinance 数据获取 =====

def fetch_yfinance_1m(period: str = "5d", interval: str = "1m") -> List[Tuple]:
    """从yfinance获取GC=F的1m K线数据。返回: [(timestamp, open, high, low, close, volume), ...]"""
    try:
        import yfinance
    except ImportError:
        print("[yfinance] 未安装，尝试安装...")
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "yfinance", "-q"],
            timeout=120, capture_output=True, text=True,
        )
        import yfinance

    print(f"[yfinance] 正在获取 {SYMBOL} period={period} interval={interval}")
    try:
        ticker = yfinance.Ticker(SYMBOL)
        df = ticker.history(period=period, interval=interval)
    except Exception as e:
        print(f"[yfinance] 获取失败: {e}")
        return []

    if df.empty:
        print("[yfinance] 返回空数据")
        return []

    rows = []
    for idx, row in df.iterrows():
        if hasattr(idx, "timestamp"):
            ts = int(idx.timestamp())
        else:
            ts = int(idx)

        o = float(row["Open"]) if not math.isnan(row["Open"]) else None
        h = float(row["High"]) if not math.isnan(row["High"]) else None
        l = float(row["Low"]) if not math.isnan(row["Low"]) else None
        c = float(row["Close"]) if not math.isnan(row["Close"]) else None
        v = float(row["Volume"]) if not math.isnan(row["Volume"]) else None

        if o is not None and h is not None and l is not None and c is not None:
            rows.append((ts, o, h, l, c, v))

    print(f"[yfinance] 获取到 {len(rows)} 条1m数据")
    return rows


# ===== xaus.com API 数据获取 =====

def fetch_xaus_intraday(hours: int = 48) -> List[Tuple]:
    """从xaus.com获取2分钟采样的盘中数据。

    返回: [(timestamp, open, high, low, close, volume=NULL), ...]
    xaus intraday返回{t, p}点，需要聚合成2分钟OHLC。
    """
    print(f"[xaus-intraday] 正在获取 {hours} 小时盘中数据...")
    try:
        r = requests.get(
            f"{XAUS_INTRADAY_URL}?hours={hours}&symbol=xau",
            timeout=20,
        )
        if r.status_code != 200:
            print(f"[xaus-intraday] HTTP {r.status_code}")
            return []

        data = r.json()
        points = data.get("points", [])
        if not points:
            print("[xaus-intraday] 无数据点")
            return []

        print(f"[xaus-intraday] 获取到 {len(points)} 个原始采样点")

        # 将{t, p}点聚合成2分钟OHLC
        # xaus采样间隔约2分钟(interval_seconds)
        interval_sec = data.get("interval_seconds", 120)

        # 按2分钟周期分组
        groups: Dict[int, List[Tuple[int, float]]] = {}
        for pt in points:
            ts = int(pt["t"])
            price = float(pt["p"])
            # 对齐到2分钟整点
            period_start = (ts // interval_sec) * interval_sec
            if period_start not in groups:
                groups[period_start] = []
            groups[period_start].append((ts, price))

        rows = []
        for period_start in sorted(groups.keys()):
            price_points = groups[period_start]
            prices = [p for _, p in sorted(price_points)]
            o = prices[0]
            h = max(prices)
            l = min(prices)
            c = prices[-1]
            rows.append((period_start, o, h, l, c, None))  # volume=NULL

        print(f"[xaus-intraday] 聚合为 {len(rows)} 条2分钟OHLC数据")
        return rows

    except Exception as e:
        print(f"[xaus-intraday] 获取失败: {e}")
        return []


def fetch_xaus_history() -> List[Tuple]:
    """从xaus.com获取日线历史数据（最多5年）。

    返回: [(timestamp, open, high, low, close, volume=NULL), ...]
    """
    print("[xaus-history] 正在获取日线历史数据...")
    try:
        r = requests.get(XAUS_HISTORY_URL, timeout=20)
        if r.status_code != 200:
            print(f"[xaus-history] HTTP {r.status_code}")
            return []

        data = r.json()
        points = data.get("points", [])
        if not points:
            print("[xaus-history] 无数据点")
            return []

        print(f"[xaus-history] 获取到 {len(points)} 个日线数据点")

        rows = []
        for pt in points:
            date_str = pt.get("d", "")
            if not date_str:
                continue
            try:
                dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
                ts = int(dt.timestamp())
            except ValueError:
                continue

            c = pt.get("c")
            h = pt.get("h", c)
            l = pt.get("l", c)
            # xaus history没有open，用close近似
            o = c

            if c is not None and h is not None and l is not None:
                rows.append((ts, float(o), float(h), float(l), float(c), None))

        print(f"[xaus-history] 转换为 {len(rows)} 条日线OHLC数据")
        return rows

    except Exception as e:
        print(f"[xaus-history] 获取失败: {e}")
        return []


# ===== 核心逻辑 =====

def collect_data(backfill: bool = False) -> Dict[str, Any]:
    """执行数据采集，返回统计信息。"""
    conn = init_db()
    stats_before = get_db_stats(conn)

    total_new_1m = 0
    total_new_1d = 0
    sources_used = []

    # ===== 第一步：尝试yfinance获取1m数据 =====
    yf_rows = []
    try:
        yf_rows = fetch_yfinance_1m(period="5d", interval="1m")
    except Exception as e:
        print(f"[yfinance] 异常: {e}")

    if yf_rows:
        new_count = insert_1m_data(conn, yf_rows, source="yfinance")
        total_new_1m += new_count
        sources_used.append("yfinance")
        print(f"[yfinance] 新增 {new_count} 条1m数据")
    else:
        # ===== 第二步：从xaus.com获取盘中数据 =====
        print("[yfinance] 无数据，尝试xaus.com intraday...")
        xaus_rows = fetch_xaus_intraday(hours=48)
        if xaus_rows:
            new_count = insert_1m_data(conn, xaus_rows, source="xaus_2m")
            total_new_1m += new_count
            sources_used.append("xaus_intraday")
            print(f"[xaus-intraday] 新增 {new_count} 条1m数据")
        else:
            print("[xaus-intraday] 无数据")

    # ===== 第四步：如果backfill模式，获取日线历史数据 =====
    if backfill:
        print("[backfill] 正在获取日线历史数据...")
        daily_rows = fetch_xaus_history()
        if daily_rows:
            new_count = insert_1d_data(conn, daily_rows)
            total_new_1d += new_count
            sources_used.append("xaus_history")
            print(f"[xaus-history] 新增 {new_count} 条日线数据")

    # ===== 聚合派生周期 =====
    agg_stats = {}
    for tf_name, tf_minutes in AGGREGATE_MAP.items():
        new_count = aggregate_1m_to_tf(conn, tf_name, tf_minutes)
        agg_stats[tf_name] = new_count
        if new_count > 0:
            print(f"[聚合] ohlcv_{tf_name} 新增 {new_count} 条")

    stats_after = get_db_stats(conn)

    # 获取最新数据时间
    latest_ts_1m = get_latest_timestamp(conn, "ohlcv_1m")
    latest_1m = datetime.fromtimestamp(latest_ts_1m, tz=timezone.utc).strftime("%Y-%m-%d %H:%M UTC") if latest_ts_1m else "无数据"

    latest_ts_1d = get_latest_timestamp(conn, "ohlcv_1d")
    latest_1d = datetime.fromtimestamp(latest_ts_1d, tz=timezone.utc).strftime("%Y-%m-%d UTC") if latest_ts_1d else "无数据"

    conn.close()

    return {
        "total_new_1m": total_new_1m,
        "total_new_1d": total_new_1d,
        "agg_stats": agg_stats,
        "sources_used": sources_used,
        "stats_before": stats_before,
        "stats_after": stats_after,
        "latest_1m": latest_1m,
        "latest_1d": latest_1d,
        "backfill": backfill,
    }


# ===== 主入口 =====

def main() -> None:
    backfill = "--backfill" in sys.argv
    print(f"[参数] backfill={backfill} DB={DB_PATH}")
    try:
        result = collect_data(backfill=backfill)

        stats = result["stats_after"]
        new_1m = result["total_new_1m"]
        new_1d = result["total_new_1d"]
        sources = " + ".join(result["sources_used"]) if result["sources_used"] else "none"

        print(f"[采集完成] 数据源={sources}")
        print(f"  本次新增1m: {new_1m} 条")
        if new_1d > 0:
            print(f"  本次新增1d: {new_1d} 条")
        print(f"  最新1m时间: {result['latest_1m']}")
        print(f"  最新1d时间: {result['latest_1d']}")
        for tf, count in stats.items():
            if count > 0:
                agg_new = result["agg_stats"].get(tf, 0)
                print(f"  ohlcv_{tf}: {count} 条" + (f" (本次+{agg_new})" if agg_new > 0 else ""))
    except Exception as e:
        print(f"[错误] {e}\n{traceback.format_exc()}")
        sys.exit(1)


if __name__ == "__main__":
    main()
