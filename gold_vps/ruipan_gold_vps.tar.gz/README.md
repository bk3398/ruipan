# 锐盘黄金监控 VPS 部署说明（2026-08-03）

## 文件清单
- `xauusd_monitor_vps.py` —— V3 策略监控主脚本（去除 Coze SDK，改 Server酱 推送）
- `gold_data_collector_vps.py` —— 数据采集脚本（去除 Coze SDK）
- `gold_data.db` —— 现有 SQLite 数据库（从 Coze 沙箱迁移）
- `monitor_position_state.json` —— 当前持仓状态（空仓）
- `ruipan_gold_wrapper.sh` —— cron 包装脚本（含交易时段判断）
- `deploy.sh` —— 一键部署脚本（在 VPS 上执行）

## 部署步骤（在 VPS Workbench 中执行）

1. 把整个 `ruipan_gold_vps` 目录上传到 VPS `/tmp/ruipan_gold_vps`（用 Workbench 的文件上传，或 scp）
2. 编辑 `deploy.sh`，把 `__SENDKEY_PLACEHOLDER__` 替换为你的 Server酱 SendKey
3. 执行：
   ```bash
   bash /tmp/ruipan_gold_vps/deploy.sh
   ```
4. 部署完成后脚本会自动：
   - 创建 `/opt/ruipan/gold` 目录并拷贝所有文件
   - 安装 Python 依赖（pandas/numpy/matplotlib/yfinance/requests）
   - 写入 cron：数据采集每 2 分钟，监控每 5 分钟
   - 配置 nginx 静态目录映射 `/static/gold/` 到图表目录
   - 重新加载 nginx

## 验证
```bash
# 手动跑一次采集
/opt/ruipan/gold/ruipan_gold_wrapper.sh collect
# 手动跑一次监控
/opt/ruipan/gold/ruipan_gold_wrapper.sh monitor
# 看日志
tail -f /var/log/ruipan_gold.log
```

## 访问图表
图表 URL：`https://perhaps-equation-thumbzilla-state.trycloudflare.com/static/gold/xauusd_monitor.png`
（等 Cloudflare 命名隧道配好后换成 raypan.cn）

## Coze 沙箱端处理
VPS 版本上线稳定运行 2~3 天后，可以：
1. 删除 Coze 端的 3 个黄金 Calendar 任务（split_7666712178334023970 等）
2. 沙箱 gold_data.db 停止写入
3. 保留回测脚本和历史报告作为研究档案

## 关键参数（与沙箱版一致）
- 进仓：1m SAR 反转 + 1m KDJ 交叉 + 5m SAR 反转（三条件 AND）
- 两步平仓：半仓（1m SAR 持续3根 + KDJ交叉）→ 全仓（5m SAR 反转）
- 止损：500 点
- 冷却：3 分钟
- 浮亏预警：200 点
- 确认窗口：3 根 1m K线
